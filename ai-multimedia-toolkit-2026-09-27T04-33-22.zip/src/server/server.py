#!/usr/bin/env python3
"""
AIVideoGen Server — your own video-generation backend.

Runs open-source image-to-video models on YOUR GPU (your laptop, your desktop, or a
free cloud GPU notebook) and exposes a tiny HTTP + SSE API that the AI Video Gen web
app talks to. No Hugging Face account, no API token, no third-party relay: the browser
talks straight to this process.

    python server.py                          # http://127.0.0.1:7860
    python server.py --tunnel cloudflare       # + a public https URL (no account needed)
    python server.py --model wan5b --preload   # load a model up front
    python server.py --list                    # show the model catalogue
    python server.py --download wan5b          # fetch the weights, then exit
    python server.py --weights                 # what is already on disk
    python server.py --source hf --hf-endpoint https://hf-mirror.com
    python server.py --precision fp16          # fp32 to be exact, fp8 on Ada/Hopper
    python server.py --lora nsfw,motion        # adapters applied to every job

Where to run it
    * Google Colab (free T4)      -> see colab/AIVideoGen_Colab.ipynb
    * Kaggle / SageMaker Studio Lab / Lightning AI Studio (all have free GPU tiers)
    * your own machine, CUDA or Apple-silicon
    Online or offline: once the weights are cached, no internet connection is needed.

API
    GET  /api/health                  server + GPU + model catalogue
    GET  /api/models                  just the catalogue
    GET  /api/weights                 the model catalogue + what is on disk
    POST /api/weights/download {model}  fetch a model's weights ahead of time
    POST /api/weights/remove   {model, confirm:"remove"}   delete them again
    POST /api/load      {model}       warm a model (downloads weights on first use)
    POST /api/generate  {...}         queue a job  -> {job}
                                     fields: model, prompt, negative, image, lastImage,
                                     width, height, duration, fps, seed, steps, guidance,
                                     motion, nsfw, native, lora/loras, interpolate
    GET  /api/status/{job}            Server-Sent Events: state/progress/done/error
    GET  /api/result/{job}            the finished video bytes (mp4)
    POST /api/cancel/{job}            stop a queued or running job
    POST /api/relay     {url,...}     forward one allow-listed request (address rotation)
                                     multipart uploads arrive base64-encoded as
                                     {bodyB64, contentType}
    GET  /api/relay/raw?url=...       stream one allow-listed GET straight back —
                                     binary-safe, so it can carry the finished
                                     clip and the model's live progress stream
    GET  /                            a plain status page you can open in a browser

Weights
    Models are fetched on first use and then stay on disk, so once a model has run
    the server keeps working with the internet unplugged. The first place it looks
    is ModelScope (fast and complete from most of the world, and reachable where
    huggingface.co is not), then Hugging Face, then the mirror named by
    --hf-endpoint. Both SDKs resume an interrupted download, so a dropped
    connection costs nothing. Nothing here needs an account or a token.

        pip install modelscope          # the ModelScope SDK (preferred source)

    Every model can also be fetched by hand, before the server is ever started:

        modelscope download --model Wan-AI/Wan2.1-T2V-14B

    Cache: ~/.cache/aivideogen/models by default (--cache / --models-dir).

Adapters and precision
    A LoRA is a small public safetensors adapter attached on top of a base model.
    Two kinds are used here: distillation (what lets a 14B model run in 4 steps
    instead of 40), and content/motion (what makes an explicit prompt actually
    explicit, and what makes the subject move). The catalogue is in LORAS; the
    web app asks for the adult ones itself when the NSFW switch is on, and any
    job may name its own with "loras": ["nsfw", "motion"] — or "lora": "none" to
    run the bare checkpoint. On a Wan 2.2 A14B model a LoRA ships as a
    high-noise/low-noise pair and each half is attached to its own transformer,
    which is the only arrangement that works.

    --precision picks the weight dtype by the name everyone uses (auto, fp32,
    fp16, bf16, fp8). `auto` is bf16 on Ampere and newer, fp16 on older CUDA and
    fp32 on CPU. fp8 needs Ada/Hopper and quietly becomes bf16 elsewhere.

    A frame rate above what the model renders at (Wan 16, LTX 24) is reached by
    ffmpeg minterpolate after the render, so a 60 fps request is 60 real frames
    per second rather than a 16 fps file with a 60 on the label. Nothing is
    upscaled without being asked: the model renders at its own rate and the
    delivered file matches what was requested.

SECURITY: this file is public source. Never put a password, token or key in it.
"""

from __future__ import annotations

import argparse
import base64
import binascii
import hmac
import io
import json
import os
import platform
import queue
import shutil
import subprocess
import sys
import threading
import time
import traceback
import uuid

VERSION = 1
SERVER_NAME = "aivideogen-server"

# --------------------------------------------------------------------------- #
#  Model catalogue.  Every entry is a diffusers pipeline on a public model repo,
#  so "more free models" simply means adding a row here.  The whole Wan family —
#  2.1 and 2.2, 5B and 14B, image-to-video, text-to-video and first/last-frame —
#  is mirrored on ModelScope, and ModelScope is what the server tries first
#  (fast, complete, and reachable where huggingface.co is not).
# --------------------------------------------------------------------------- #
#
#  fields:
#    id         short id used by the web app
#    label      human name
#    repo       Hugging Face model repo id (public, no token required)
#    ms         ModelScope repo id, when one exists. The ModelScope copies of the
#               Wan family are complete; where a repo is missing there, the
#               Hugging Face copy is used instead.
#    source     "ms" -> always ModelScope, "hf" -> always Hugging Face.
#               Omitted = follow --source (default "auto").
#    pipeline   diffusers class name
#    family     which call-shape to use (see call_kwargs)
#    fps        native frame rate of the model
#    minSec/maxSec  native clip length the model can produce in one shot
#    frameStep  frames must satisfy (frames - 1) % frameStep == 0
#    steps      default inference steps
#    guidance   default guidance scale
#    vramGb     rough fp16 VRAM need — CPU offload gets you under it, slowly
#    sizeGb     rough first-run weight download, so it is not a surprise
#    native     long side the model was trained at: a smaller request is scaled
#               up to it, so a 720p model is never fed a 480p frame
#    paths      optional allow_patterns — trims a fat repo down to its components
#    lora       optional distillation adapter, downloaded and attached
#               automatically (a 4-step "Lightning" run instead of 30-50 steps)
#    caps       {i2v, t2v, prompt, resolution, nsfw, endFrame}
#    note       one-line description shown in the app
#
#  Everything here runs on your own machine, so no route has a content filter:
#  the `nsfw` cap means "this model will render whatever you ask".
MODELS = [
    # ---------------------------------------------------------------- quality tier
    {
        "id": "wan21_720p",
        "label": "Wan 2.1 I2V 14B 720p",
        "repo": "Wan-AI/Wan2.1-I2V-14B-720P-Diffusers",
        "ms": "Wan-AI/Wan2.1-I2V-14B-720P-Diffusers",
        "pipeline": "WanImageToVideoPipeline",
        "family": "wan_i2v",
        "fps": 16,
        "minSec": 1.0,
        "maxSec": 5.0,
        "frameStep": 4,
        "steps": 40,
        "guidance": 5.0,
        "vramGb": 28,
        "sizeGb": 90,
        "native": 1280,
        "caps": {"i2v": True, "t2v": False, "prompt": True, "resolution": True, "nsfw": True},
        "note": "The quality king: Wan 2.1's 14B image-to-video model at its native 720p. 90 GB of weights, fits 24GB+, works on 16GB with CPU offload (slowly).",
    },
    {
        "id": "wan21_480p",
        "label": "Wan 2.1 I2V 14B 480p",
        "repo": "Wan-AI/Wan2.1-I2V-14B-480P-Diffusers",
        "ms": "Wan-AI/Wan2.1-I2V-14B-480P-Diffusers",
        "pipeline": "WanImageToVideoPipeline",
        "family": "wan_i2v",
        "fps": 16,
        "minSec": 1.0,
        "maxSec": 5.0,
        "frameStep": 4,
        "steps": 40,
        "guidance": 5.0,
        "vramGb": 28,
        "sizeGb": 90,
        "native": 832,
        "caps": {"i2v": True, "t2v": False, "prompt": True, "resolution": True, "nsfw": True},
        "note": "The same 14B network as the 720p model, released at 480p — better motion and identity than the 5B models, a quarter of the pixels to render.",
    },
    {
        "id": "wan21_flf2v",
        "label": "Wan 2.1 FLF2V 14B 720p",
        "repo": "Wan-AI/Wan2.1-FLF2V-14B-720P-diffusers",
        "ms": "Wan-AI/Wan2.1-FLF2V-14B-720P-diffusers",
        "pipeline": "WanImageToVideoPipeline",
        "family": "wan_i2v",
        "fps": 16,
        "minSec": 2.0,
        "maxSec": 5.0,
        "frameStep": 4,
        "steps": 40,
        "guidance": 5.0,
        "vramGb": 28,
        "sizeGb": 90,
        "native": 1280,
        "caps": {"i2v": True, "t2v": False, "prompt": True, "resolution": True, "nsfw": True, "endFrame": True},
        "note": "First frame + last frame: hand it both ends of a shot and it invents the motion in between. The reliable way to direct one specific move.",
    },
    {
        "id": "wan22a14b",
        "label": "Wan 2.2 I2V A14B",
        "repo": "Wan-AI/Wan2.2-I2V-A14B-Diffusers",
        "ms": "Wan-AI/Wan2.2-I2V-A14B-Diffusers",
        "pipeline": "WanImageToVideoPipeline",
        "family": "wan_i2v",
        "fps": 16,
        "minSec": 1.0,
        "maxSec": 5.0,
        "frameStep": 4,
        "steps": 30,
        "guidance": 5.0,
        "vramGb": 30,
        "sizeGb": 127,
        "native": 1280,
        "caps": {"i2v": True, "t2v": False, "prompt": True, "resolution": True, "nsfw": True},
        "lora": {
            "repo": "lightx2v/Wan2.2-Distill-Loras",
            "ms": "lightx2v/Wan2.2-Distill-Loras",
            "files": [
                "wan2.2_i2v_A14b_high_noise_lora_rank64_lightx2v_4step_1022.safetensors",
                "wan2.2_i2v_A14b_low_noise_lora_rank64_lightx2v_4step_1022.safetensors",
            ],
            "sizeGb": 1.4,
            "steps": 4,
            "guidance": 1.0,
            "note": "4-step Lightning distillation (lightx2v)",
        },
        "note": "Wan 2.2's two-expert 14B (high-noise + low-noise): the best motion and identity on this list. 127 GB of weights and wants 30GB — the bundled Lightning LoRA cuts 30 steps down to 4.",
    },
    {
        "id": "wan22_t2v_a14b",
        "label": "Wan 2.2 T2V A14B",
        "repo": "Wan-AI/Wan2.2-T2V-A14B-Diffusers",
        "ms": "Wan-AI/Wan2.2-T2V-A14B-Diffusers",
        "pipeline": "WanPipeline",
        "family": "wan_t2v",
        "fps": 16,
        "minSec": 1.0,
        "maxSec": 5.0,
        "frameStep": 4,
        "steps": 30,
        "guidance": 5.0,
        "vramGb": 30,
        "sizeGb": 127,
        "native": 1280,
        "caps": {"i2v": False, "t2v": True, "prompt": True, "resolution": True, "nsfw": True},
        "lora": {
            "repo": "lightx2v/Wan2.2-Distill-Loras",
            "ms": "lightx2v/Wan2.2-Distill-Loras",
            "files": [
                "wan2.2_t2v_A14b_high_noise_lora_rank64_lightx2v_4step_1217.safetensors",
                "wan2.2_t2v_A14b_low_noise_lora_rank64_lightx2v_4step_1217.safetensors",
            ],
            "sizeGb": 1.3,
            "steps": 4,
            "guidance": 1.0,
            "note": "4-step Lightning distillation (lightx2v)",
        },
        "note": "The 14B text-to-video half of Wan 2.2 — no reference image, it draws the whole shot. Lightning LoRA included.",
    },
    # ------------------------------------------------------- HunyuanVideo tier
    # Tencent's 13B open video foundation model. Added from the roadmap's model
    # audit; the diffusers pipeline is very video-memory hungry, so treat these
    # as "bring a big card" routes. If the installed diffusers has no
    # HunyuanVideoPipeline the loader will say so by name.
    #
    # The argument contract was then checked line by line against the pipeline
    # sources (`pipelines/hunyuan_video/pipeline_hunyuan_video_image2video.py`
    # and its t2v sibling) rather than assumed, because four of its rules are
    # easy to get wrong and none of them fail loudly:
    #
    #   * `num_frames` must be of the form 4n+1 (the pipeline's own default is
    #     129) — `align_frames(x, 4)` is already `1 + 4k`, so the frame maths
    #     below is correct for this family as it stands.
    #   * the model is **CFG-distilled**, so `guidance_scale` is the *embedded*
    #     guidance, not true classifier-free guidance; the pipeline's own
    #     example passes 6.0, which is what these specs set. `true_cfg_scale`
    #     (default 1.0) is the separate dial and is left alone.
    #   * the LLaVA-style prompt template (system + `<image>` + user turns,
    #     `crop_start` 103) is the pipeline's *default* `prompt_template`, so
    #     nothing has to be threaded through from here — and nothing should be.
    #   * height and width must be divisible by 16; `call_kwargs()` already
    #     rounds to 16 for every family.
    #
    # What is still NOT verified is the part only a GPU can answer: that these
    # weights load and render at the expected time on real hardware. Treat the
    # first run as a test, and see the HunyuanVideo 1.5 note below.
    {
        "id": "hunyuan_t2v",
        "label": "HunyuanVideo T2V 13B",
        "repo": "hunyuanvideo-community/HunyuanVideo",
        "pipeline": "HunyuanVideoPipeline",
        "family": "hunyuan",
        "fps": 24,
        "minSec": 2.0,
        "maxSec": 5.0,
        "frameStep": 4,
        "steps": 50,
        "guidance": 6.0,
        "vramGb": 45,
        "sizeGb": 26,
        "native": 1280,
        "caps": {"i2v": False, "t2v": True, "prompt": True, "resolution": True, "nsfw": True},
        "note": "Tencent HunyuanVideo: the strongest open text-to-video model here, but ~45GB VRAM to run comfortably (24GB only with full CPU offload). Its argument contract is verified against the diffusers pipeline source; it has not been rendered on a GPU from this project, so treat the first run as a test.",
    },
    {
        "id": "hunyuan_i2v",
        "label": "HunyuanVideo I2V 13B",
        "repo": "hunyuanvideo-community/HunyuanVideo-I2V",
        "pipeline": "HunyuanVideoImageToVideoPipeline",
        "family": "hunyuan",
        "fps": 24,
        "minSec": 2.0,
        "maxSec": 5.0,
        "frameStep": 4,
        "steps": 50,
        "guidance": 6.0,
        "vramGb": 45,
        "sizeGb": 30,
        "native": 1280,
        "caps": {"i2v": True, "t2v": False, "prompt": True, "resolution": True, "nsfw": True},
        "note": "The image-to-video half of HunyuanVideo — very high fidelity, same heavy VRAM cost, and the one Hunyuan model here that takes a reference picture. Argument contract verified against the diffusers pipeline source; not yet rendered on a GPU from this project. (HunyuanVideo 1.5, Tencent's newer ~8B release, has no diffusers pipeline yet — the free HunyuanVideo 1.5 Space in src/providers.js is how this app uses it.)",
    },
    {
        "id": "wan5b",
        "label": "Wan 2.2 TI2V 5B",
        "repo": "Wan-AI/Wan2.2-TI2V-5B-Diffusers",
        "ms": "Wan-AI/Wan2.2-TI2V-5B-Diffusers",
        "pipeline": "WanPipeline",
        "family": "wan_ti2v",
        "fps": 24,
        "minSec": 1.0,
        "maxSec": 5.0,
        "frameStep": 4,
        "steps": 40,
        "guidance": 5.0,
        "vramGb": 14,
        "sizeGb": 35,
        "native": 1280,
        "caps": {"i2v": True, "t2v": True, "prompt": True, "resolution": True, "nsfw": True},
        "note": "Best all-rounder that still fits a free 16GB GPU: 720p, 24fps, one unified 5B model for image or text.",
    },
    {
        "id": "wan21_t2v14b",
        "label": "Wan 2.1 T2V 14B",
        "repo": "Wan-AI/Wan2.1-T2V-14B-Diffusers",
        "ms": "Wan-AI/Wan2.1-T2V-14B-Diffusers",
        "pipeline": "WanPipeline",
        "family": "wan_t2v",
        "fps": 16,
        "minSec": 1.0,
        "maxSec": 5.0,
        "frameStep": 4,
        "steps": 50,
        "guidance": 5.0,
        "vramGb": 28,
        "sizeGb": 81,
        "native": 1280,
        "caps": {"i2v": False, "t2v": True, "prompt": True, "resolution": True, "nsfw": True},
        "note": "The 14B text-to-video model that made Wan's reputation. Text only; 81 GB of weights.",
    },
    {
        "id": "cogvideox5b_i2v",
        "label": "CogVideoX 5B I2V",
        "repo": "zai-org/CogVideoX-5b-I2V",
        "ms": "AI-ModelScope/CogVideoX-5b-I2V",
        "pipeline": "CogVideoXImageToVideoPipeline",
        "family": "cogvideox_i2v",
        "fps": 8,
        "minSec": 5.0,
        "maxSec": 5.0,
        "frameStep": 4,
        "steps": 50,
        "guidance": 6.0,
        "vramGb": 18,
        "sizeGb": 22,
        "caps": {"i2v": True, "t2v": False, "prompt": True, "resolution": True, "nsfw": True},
        "note": "CogVideoX's image-to-video build: very strong prompt following, ~5s shots at 8fps. Lighter than any 14B.",
    },
    {
        "id": "cogvideox",
        "label": "CogVideoX 1.5 5B I2V",
        "repo": "zai-org/CogVideoX1.5-5B-I2V",
        "source": "hf",
        "pipeline": "CogVideoXImageToVideoPipeline",
        "family": "cogvideox_i2v",
        "fps": 16,
        "minSec": 5.0,
        "maxSec": 5.0,
        "frameStep": 4,
        "steps": 50,
        "guidance": 6.0,
        "vramGb": 20,
        "sizeGb": 31,
        "caps": {"i2v": True, "t2v": False, "prompt": True, "resolution": True, "nsfw": True},
        "note": "Smooth, coherent motion and very forgiving on weaker GPUs. Fixed ~5s shots. (Hugging Face only — no ModelScope copy of this one.)",
    },
    {
        "id": "ltx",
        "label": "LTX Video 2B",
        "repo": "Lightricks/LTX-Video",
        "ms": "Lightricks/LTX-Video",
        "pipeline": "LTXPipeline",
        "family": "ltx",
        "fps": 24,
        "minSec": 1.0,
        "maxSec": 5.0,
        "frameStep": 8,
        "steps": 30,
        "guidance": 3.0,
        "vramGb": 12,
        "sizeGb": 12,
        "paths": ["*.json", "*.txt", "transformer/*", "vae/*", "text_encoder/*", "tokenizer/*", "scheduler/*"],
        "caps": {"i2v": True, "t2v": True, "prompt": True, "resolution": True, "nsfw": True},
        "note": "Very fast 2B model — good on small cards, likes 24fps short shots. (Its repo ships every checkpoint ever released; only the 12 GB of pipeline files are pulled.)",
    },
    {
        "id": "svd",
        "label": "Stable Video Diffusion XT",
        "repo": "stabilityai/stable-video-diffusion-img2vid-xt",
        "ms": "AI-ModelScope/stable-video-diffusion-img2vid-xt",
        "pipeline": "StableVideoDiffusionPipeline",
        "family": "svd",
        "fps": 7,
        "minSec": 2.0,
        "maxSec": 4.0,
        "frameStep": 0,
        "steps": 25,
        "guidance": 3.0,
        "vramGb": 9,
        "sizeGb": 33,
        "caps": {"i2v": True, "t2v": False, "prompt": False, "resolution": True, "nsfw": True},
        "note": "Smallest and fastest. Ignores your prompt; motion is set by the strength slider.",
    },
    {
        "id": "wan13b",
        "label": "Wan 2.1 T2V 1.3B",
        "repo": "Wan-AI/Wan2.1-T2V-1.3B-Diffusers",
        "ms": "Wan-AI/Wan2.1-T2V-1.3B-Diffusers",
        "pipeline": "WanPipeline",
        "family": "wan_t2v",
        "fps": 16,
        "minSec": 1.0,
        "maxSec": 5.0,
        "frameStep": 4,
        "steps": 50,
        "guidance": 5.0,
        "vramGb": 8,
        "sizeGb": 29,
        "caps": {"i2v": False, "t2v": True, "prompt": True, "resolution": True, "nsfw": True},
        "note": "Tiny text-to-video model — runs on almost anything, including CPU (slowly).",
    },
    {
        "id": "cogvideox5b",
        "label": "CogVideoX 5B (text)",
        "repo": "zai-org/CogVideoX-5b",
        "ms": "AI-ModelScope/CogVideoX-5b",
        "pipeline": "CogVideoXPipeline",
        "family": "cogvideox_t2v",
        "fps": 8,
        "minSec": 2.0,
        "maxSec": 6.0,
        "frameStep": 4,
        "steps": 50,
        "guidance": 6.0,
        "vramGb": 14,
        "sizeGb": 22,
        "caps": {"i2v": False, "t2v": True, "prompt": True, "resolution": True, "nsfw": True},
        "note": "The best pure text-to-video quality that still fits 16 GB with CPU offload.",
    },
    {
        "id": "cogvideox2b",
        "label": "CogVideoX 2B (text)",
        "repo": "zai-org/CogVideoX-2b",
        "ms": "AI-ModelScope/CogVideoX-2b",
        "pipeline": "CogVideoXPipeline",
        "family": "cogvideox_t2v",
        "fps": 8,
        "minSec": 2.0,
        "maxSec": 6.0,
        "frameStep": 4,
        "steps": 50,
        "guidance": 6.0,
        "vramGb": 9,
        "sizeGb": 14,
        "caps": {"i2v": False, "t2v": True, "prompt": True, "resolution": True, "nsfw": True},
        "note": "Tiny text-to-video model, ~6s per shot. Great first choice on a free T4.",
    },
    {
        "id": "i2vgenxl",
        "label": "I2VGen-XL (image)",
        "repo": "ali-vilab/i2vgen-xl",
        "ms": "AI-ModelScope/i2vgen-xl",
        "pipeline": "I2VGenXLPipeline",
        "family": "i2vgen",
        "fps": 8,
        "minSec": 2.0,
        "maxSec": 2.0,
        "frameStep": 0,
        "steps": 50,
        "guidance": 9.0,
        "vramGb": 12,
        "sizeGb": 18,
        "paths": ["*.json", "*.txt", "unet/*", "vae/*", "text_encoder/*", "tokenizer/*", "scheduler/*", "image_encoder/*"],
        "caps": {"i2v": True, "t2v": False, "prompt": True, "resolution": True, "nsfw": True},
        "note": "Alibaba's 7B image-to-video model. Short 16-frame shots — chain segments for longer.",
    },
    {
        "id": "zeroscope",
        "label": "Zeroscope v2 576w (text)",
        "repo": "cerspense/zeroscope_v2_576w",
        "source": "hf",
        "pipeline": "TextToVideoSDPipeline",
        "family": "zeroscope",
        "fps": 8,
        "minSec": 1.0,
        "maxSec": 3.0,
        "frameStep": 0,
        "steps": 40,
        "guidance": 9.0,
        "vramGb": 4,
        "sizeGb": 4,
        "caps": {"i2v": False, "t2v": True, "prompt": True, "resolution": True, "nsfw": True},
        "note": "~4 GB and CPU-friendly — the one to pick when you have no real GPU at all.",
    },
]


MODEL_BY_ID = {m["id"]: m for m in MODELS}


# --------------------------------------------------------------------------- #
#  LoRA catalogue.
#
#  A LoRA is a small safetensors adapter (a few hundred MB) attached on top of a
#  base model. Two kinds matter here:
#
#    * distillation — 4-to-8 step "Lightning" adapters that turn a 30-40 step
#      model into a 4-step one. These are named in the `lora` field of the big
#      models above and are attached automatically.
#    * content and motion — adapters that teach the base model something it was
#      never trained on. For this app that means explicit adult content (the Wan
#      family ships with none, and a prompt alone will not conjure it reliably)
#      and stronger body movement.
#
#  Wan 2.2's A14B checkpoint is two experts in one: a high-noise expert that runs
#  the first steps and a low-noise expert that finishes the shot. A LoRA for it
#  ships as that same pair, and each half has to be attached to *its* transformer
#  — attaching both to one, or attaching a half to the wrong one, is worse than
#  attaching nothing. `files` below is either the pair (high/low) or None, in
#  which case the downloaded folder is globbed for .safetensors and split by the
#  high/low in the filenames.
#
#  Every file is public, free and plain safetensors. Nothing is downloaded until
#  the adapter is actually chosen, and it then lives in the weights cache next to
#  the models (weights.json), so it is fetched once.
# --------------------------------------------------------------------------- #
LORAS = [
    {
        "id": "distill",
        "label": "Lightning (4-step distillation)",
        "repo": "lightx2v/Wan2.2-Distill-Loras",
        "ms": "lightx2v/Wan2.2-Distill-Loras",
        "steps": 4,
        "guidance": 1.0,
        "preset": True,
        "note": "The distillation adapter the 14B models above already name: 30 steps become 4. On the A14B models it is attached per expert automatically.",
    },
    {
        "id": "nsfw",
        "label": "NSFW (adult content, general)",
        "repo": "lopi999/Wan2.2-I2V_General-NSFW-Lora",
        "ms": "lopi999/Wan2.2-I2V_General-NSFW-Lora",
        "files": ["NSFW-22-H-e8.safetensors", "NSFW-22-L-e8.safetensors"],
        "sizeGb": 1.6,
        "note": "A mirror of the most-downloaded general adult LoRA for Wan 2.2 (400k+ downloads on Civitai). Trained on explicit video, and it is the difference between the model hinting at something and the model showing it.",
    },
    {
        "id": "nsfw_anatomy",
        "label": "NSFW anatomy detail",
        "repo": "JERRYNPC/WAN2.2-LORA-NSFW",
        "ms": "JERRYNPC/WAN2.2-LORA-NSFW",
        "files": None,
        "sizeGb": 0.5,
        "note": "Anatomy-focused adult adapter — pairs well with the general one for close shots.",
    },
    {
        "id": "motion",
        "label": "Motion enhancer (more body movement)",
        "repo": "rzgar/Wan2.2-Bernini-R-Motion-Enhancer-n4w-i2v",
        "ms": "rzgar/Wan2.2-Bernini-R-Motion-Enhancer-n4w-i2v",
        "files": None,
        "sizeGb": 1.2,
        "note": "Trained to make the subject move more, and further. Aimed at the 'nothing in the shot moves' failure: it does not change what the frame contains, only how much the body does inside it.",
    },
]
LORA_BY_ID = {l["id"]: l for l in LORAS}


def safetensor_files(folder):
    """Every .safetensors in a downloaded adapter folder, largest first."""
    found = []
    for root, _dirs, files in os.walk(folder):
        for name in files:
            if name.lower().endswith(".safetensors"):
                path = os.path.join(root, name)
                try:
                    found.append((os.path.getsize(path), path))
                except OSError:
                    pass
    found.sort(reverse=True)
    return [p for _s, p in found]


def split_experts(paths):
    """Split a Wan 2.2 A14B adapter into (high-noise, low-noise) halves.

    The pair is named either `...high_noise...` / `...low_noise...` (lightx2v) or
    `NSFW-22-H-...` / `NSFW-22-L-...` (the community LoRAs), so both are matched
    on a *standalone* h/l or the words high/low. A single file that names neither
    is a whole-model adapter and comes back as the high half with no low half.
    """
    high, low, rest = [], [], []
    for path in paths:
        name = os.path.basename(path).lower()
        words = name.replace("-", " ").replace("_", " ").replace(".", " ").split()
        is_low = "low" in words or "l" in words or "low_noise" in name
        is_high = "high" in words or "h" in words or "high_noise" in name
        if is_low and not is_high:
            low.append(path)
        elif is_high and not is_low:
            high.append(path)
        else:
            rest.append(path)
    if not high and rest:
        high = rest[:1]
        rest = rest[1:]
    return high, low


def interpolate_video(src, dst, target_fps):
    """Raise a clip's frame rate in place, with motion-compensated interpolation.

    A model renders at one rate (Wan at 16 fps, LTX at 24) and cannot be asked
    for another. Rather than deliver a 16 fps file labelled 60, the clip is run
    through ffmpeg's `minterpolate` filter, which *estimates* the motion between
    two frames and draws the frames in between. It costs nothing but CPU time,
    and it is what makes the frame-rate control real on this route.

    Returns the path to use (the new file on success, the original on failure) —
    never raises, because a clip in the model's own rate is still a good clip.
    """
    try:
        import imageio_ffmpeg

        ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return src
    # yuv420p needs even dimensions, and a model can hand back an odd edge.
    vf = (
        f"minterpolate=fps={int(target_fps)}:mi_mode=mci:mc_mode=aobmc:"
        "me_mode=bidir:vsbmc=1,scale=trunc(iw/2)*2:trunc(ih/2)*2"
    )
    cmd = [
        ffmpeg, "-y", "-loglevel", "error",
        "-i", src,
        "-an",
        "-vf", vf,
        "-c:v", "libx264", "-preset", "medium", "-crf", "16",
        "-pix_fmt", "yuv420p",
        dst,
    ]
    try:
        done = subprocess.run(cmd, capture_output=True, timeout=1800)
    except Exception:
        return src
    if done.returncode == 0 and os.path.exists(dst) and os.path.getsize(dst) > 1024:
        return dst
    return src


# Weight precision. The CLI calls these fp16/fp32/fp8 (the names everyone uses);
# torch calls them float16/float32/float8_e4m3fn. `auto` picks by capability.
DTYPE_ALIASES = {
    "fp16": "float16",
    "half": "float16",
    "float16": "float16",
    "bf16": "bfloat16",
    "bfloat16": "bfloat16",
    "fp32": "float32",
    "float32": "float32",
    "full": "float32",
    "fp8": "float8_e4m3fn",
    "float8": "float8_e4m3fn",
    "float8_e4m3fn": "float8_e4m3fn",
    "fp8_e4m3fn": "float8_e4m3fn",
}


def resolve_dtype(torch, spec, override=None):
    """The precision to load the weights in.

    auto  → bf16 on Ampere and newer, fp16 on older CUDA, fp32 on CPU
    fp16  → half precision: the usual choice, half the VRAM
    bf16  → same size, wider exponent: the sane choice on Ampere+
    fp32  → full precision: slowest, but the model that "half precision broke"
            runs exactly here
    fp8   → e4m3 float8 weights, which need Ada/Hopper to multiply. Asked for on
            an older GPU it silently degrades to bf16 rather than failing
            mid-render, because a 20-minute job that dies at step 3 is worse
            than one that started in a precision it can actually compute.
    """
    key = str(override or "").strip().lower()
    if key and key not in ("auto", "none", "default"):
        want = DTYPE_ALIASES.get(key, key)
        dt = getattr(torch, want, None)
        if dt is not None:
            if want.startswith("float8"):
                if not torch.cuda.is_available():
                    return torch.float32
                if torch.cuda.get_device_capability()[0] < 8:
                    return torch.bfloat16
            return dt
    if not torch.cuda.is_available():
        return torch.float32
    major = torch.cuda.get_device_capability()[0]
    return torch.bfloat16 if major >= 8 else torch.float16


def align_frames(frames, step):
    """(frames - 1) must be divisible by `step` for most video DiTs."""
    frames = max(9, int(frames))
    if step and step > 1:
        frames = 1 + round((frames - 1) / step) * step
    return frames


# --------------------------------------------------------------------------- #
#  Weights.  A model's files are fetched once and then live on disk, so the
#  server keeps working with the internet unplugged afterwards.
#
#  Where they come from: ModelScope first — its copy of the whole Wan family is
#  complete, it needs no mirror, and it is usually far quicker than
#  huggingface.co outside the US and EU — then Hugging Face, then (if
#  huggingface.co cannot be reached) the public mirror named by --hf-endpoint
#  (https://hf-mirror.com works from most places where huggingface.co does not).
#  Both SDKs resume partial downloads, so an interrupted run just continues.
# --------------------------------------------------------------------------- #
WEIGHTS_INDEX = "weights.json"

#  Formats no diffusers pipeline can load. Skipping them matters: these repos
#  carry a copy of every checkpoint the authors ever released, and the duplicate
#  fp32/Flax/TF weight files run to tens of gigabytes. If a trimmed download ever
#  turns out to be missing something, the loader re-fetches the full repo once.
JUNK_PATTERNS = [
    "*.pth", "*.pt", "*.ckpt", "*.msgpack", "*.h5", "*.ot",
    "*.onnx", "*.tflite", "*.tar", "*.zip", "*.gguf",
    "flax_model*", "tf_model*",
]


def have_module(name):
    try:
        __import__(name)
        return True
    except Exception:
        return False


def accepted_kwargs(fn, **wanted):
    """Keep only the keyword arguments `fn` really accepts.

    ModelScope and huggingface_hub both rename arguments between releases
    (`allow_file_pattern` became `allow_patterns`; `local_dir` came later than
    `cache_dir`). A TypeError from a version skew would be a miserable first-run
    experience, so we ask the function what it takes instead of guessing.
    """
    import inspect

    try:
        params = inspect.signature(fn).parameters
    except (TypeError, ValueError):
        return {k: v for k, v in wanted.items() if v is not None}
    return {k: v for k, v in wanted.items() if v is not None and k in params}


def human_size(n):
    n = float(n or 0)
    if n < 1024:
        return f"{n:.0f} B"
    n /= 1024
    if n < 1024:
        return f"{n:.0f} KB"
    n /= 1024
    if n < 1024:
        return f"{n:.0f} MB"
    return f"{n / 1024:.1f} GB"


class _SizeWatch(threading.Thread):
    """Reports how many bytes a download has landed so far.

    Neither SDK exposes a progress callback, so we watch the folder grow. It only
    runs while a download is in flight, and only emits when a job is listening.
    """

    def __init__(self, path, expected_bytes, job, label):
        super().__init__(daemon=True)
        self.path = path
        self.expected = float(expected_bytes or 0)
        self.job = job
        self.label = label
        self.stop = threading.Event()

    def run(self):
        while not self.stop.wait(2.5):
            if self.job is None:
                continue
            got = 0
            try:
                for root, _dirs, files in os.walk(self.path):
                    for name in files:
                        try:
                            got += os.path.getsize(os.path.join(root, name))
                        except OSError:
                            pass
            except OSError:
                continue
            frac = 0.01
            tail = ""
            if self.expected:
                frac = max(0.01, min(0.94, 0.02 + 0.92 * got / self.expected))
                tail = f" / ~{human_size(self.expected)}"
            try:
                self.job.emit(
                    state="downloading",
                    progress=frac,
                    message=f"downloading {self.label} weights — {human_size(got)}{tail}",
                )
            except Exception:
                pass


class Weights:
    """Locates — and if necessary downloads — the files behind a model repo."""

    def __init__(self, args, log=None):
        self.args = args
        self.log = log or (lambda text, level="info": print(text, flush=True))
        self.root = os.path.abspath(
            os.path.expanduser(args.models_dir or os.path.join(args.cache, "models"))
        )
        os.makedirs(self.root, exist_ok=True)
        self.index_path = os.path.join(self.root, WEIGHTS_INDEX)
        self.lock = threading.Lock()
        self.index = {}
        self.load()

    # -- the index --------------------------------------------------------- #
    def load(self):
        try:
            with open(self.index_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                self.index = data
        except Exception:
            self.index = {}

    def save(self):
        try:
            tmp = self.index_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.index, f, indent=1, sort_keys=True)
            os.replace(tmp, self.index_path)
        except Exception as e:
            self.log(f"could not write {self.index_path}: {e}", "warn")

    @staticmethod
    def key(repo, tag="main"):
        return repo if tag == "main" else f"{repo}#{tag}"

    def peek(self, repo, tag="main"):
        if not repo:
            return None
        entry = self.index.get(self.key(repo, tag))
        if entry and entry.get("path") and os.path.isdir(entry["path"]):
            return entry
        return None

    @staticmethod
    def disk_bytes(path):
        total = 0
        for root, _dirs, files in os.walk(path):
            for name in files:
                try:
                    total += os.path.getsize(os.path.join(root, name))
                except OSError:
                    pass
        return total

    def folder(self, repo):
        return os.path.join(self.root, repo.replace("/", "--"))

    # -- which source to try, in order ------------------------------------- #
    def sources(self, repo, ms_id=None, source=None):
        """The download attempts to make, best first, as (kind, repo_id, endpoint)."""
        want = str(source or self.args.source or "auto").strip().lower()
        want = {
            "modelscope": "ms", "model_scope": "ms", "ms": "ms",
            "huggingface": "hf", "hf": "hf", "hf-mirror": "hf",
        }.get(want, "auto")
        chain = []
        if want in ("auto", "ms") and ms_id:
            chain.append(("ms", ms_id, None))
        if want in ("auto", "hf") and repo:
            chain.append(("hf", repo, self.args.hf_endpoint or None))
            if not self.args.hf_endpoint:
                chain.append(("hf", repo, "https://hf-mirror.com"))
        if not chain and repo:
            chain.append(("hf", repo, self.args.hf_endpoint or None))
        if not chain and ms_id:
            chain.append(("ms", ms_id, None))
        return chain

    # -- download ---------------------------------------------------------- #
    def fetch(self, repo, ms_id=None, paths=None, size_gb=None, source=None,
              job=None, tag="main", label=None, strict=False, force=False):
        """Return a local folder holding `repo`'s weights, downloading if needed."""
        label = label or repo
        if not force:
            hit = self.peek(repo, tag)
            if hit:
                return hit["path"]
        target = self.folder(repo)
        os.makedirs(target, exist_ok=True)
        attempts = self.sources(repo, ms_id, source)
        if self.args.offline:
            raise RuntimeError(
                f"offline mode is on and {label} has not been downloaded yet (expected in {target})"
            )
        errors = []
        for kind, repo_id, endpoint in attempts:
            try:
                self._download(kind, repo_id, target, paths, job, label, size_gb, endpoint, strict)
                gb = round(self.disk_bytes(target) / 1e9, 2)
                entry = {
                    "repo": repo,
                    "source": kind,
                    "repo_id": repo_id,
                    "path": target,
                    "gb": gb,
                    "at": round(time.time(), 1),
                }
                with self.lock:
                    self.index[self.key(repo, tag)] = entry
                    self.save()
                self.log(f"weights ready: {label} · {gb} GB · {kind} ({repo_id}) → {target}")
                return target
            except Exception as e:  # try the next source
                text = str(e).strip()
                msg = text.splitlines()[0][:220] if text else e.__class__.__name__
                errors.append(f"{kind} {repo_id}: {msg}")
                self.log(f"download via {kind} ({repo_id}) failed: {msg}", "warn")
        raise RuntimeError(f"could not download {label} — " + " | ".join(errors))

    def _download(self, kind, repo_id, target, paths, job, label, size_gb, endpoint, strict):
        # Ask about the SDK first: "pip install modelscope" is a far better answer
        # than whatever the import would have said.
        if kind == "ms" and not have_module("modelscope"):
            raise RuntimeError(
                "the 'modelscope' package is not installed (pip install modelscope)"
            )
        if kind == "hf" and not have_module("huggingface_hub"):
            raise RuntimeError(
                "the 'huggingface_hub' package is not installed (pip install huggingface_hub)"
            )
        patterns = None if strict else paths
        ignore = None if strict else JUNK_PATTERNS
        if job is not None:
            where = "ModelScope" if kind == "ms" else ("Hugging Face mirror" if endpoint else "Hugging Face")
            tail = f" (~{size_gb:g} GB, one time)" if size_gb else ""
            job.emit(
                state="downloading",
                progress=0.01,
                message=f"first run — fetching {label} weights from {where}{tail}…",
            )
        # Byte-count reporting is a nicety; if the platform cannot start the
        # watcher thread the download itself must still go ahead.
        watcher = _SizeWatch(target, (size_gb or 0) * 1e9, job, label)
        try:
            watcher.start()
        except Exception:
            pass
        try:
            if kind == "ms":
                if not have_module("modelscope"):
                    raise RuntimeError(
                        "the 'modelscope' package is not installed (pip install modelscope)"
                    )
                from modelscope import snapshot_download

                os.environ.setdefault("MODELSCOPE_CACHE", self.root)
                kw = accepted_kwargs(
                    snapshot_download,
                    cache_dir=self.root,
                    local_dir=target,
                    revision=self.args.revision or None,
                    allow_patterns=patterns,
                    allow_file_pattern=patterns,
                    ignore_patterns=ignore,
                    max_workers=4,
                )
                out = snapshot_download(repo_id, **kw)
            else:
                from huggingface_hub import snapshot_download

                if endpoint:
                    os.environ["HF_ENDPOINT"] = endpoint
                    self.log(f"using the Hugging Face mirror {endpoint}")
                kw = accepted_kwargs(
                    snapshot_download,
                    repo_id=repo_id,
                    cache_dir=os.path.join(self.root, ".hf"),
                    local_dir=target,
                    revision=self.args.revision or None,
                    allow_patterns=patterns,
                    ignore_patterns=ignore,
                    max_workers=4,
                )
                out = snapshot_download(**kw)
        finally:
            watcher.stop.set()
        return out or target

    def remove(self, repo, tag="main"):
        entry = self.peek(repo, tag)
        if not entry:
            with self.lock:
                self.index.pop(self.key(repo, tag), None)
                self.save()
            return 0
        freed = self.disk_bytes(entry["path"])
        shutil.rmtree(entry["path"], ignore_errors=True)
        with self.lock:
            self.index.pop(self.key(repo, tag), None)
            self.save()
        return freed


# --------------------------------------------------------------------------- #
#  Job store: one worker thread, because a GPU can only do one thing at a time.
# --------------------------------------------------------------------------- #
class Job:
    def __init__(self, req):
        self.id = uuid.uuid4().hex[:16]
        self.req = req
        self.state = "queued"
        self.progress = 0.0
        self.message = "queued"
        self.started = time.time()
        self.elapsed = 0.0
        self.path = None
        self.meta = {}
        self.error = None
        self.detail = None
        self.cancel = threading.Event()
        self.listeners = []
        self.lock = threading.Lock()

    def emit(self, **kw):
        with self.lock:
            for k, v in kw.items():
                setattr(self, k, v)
            self.elapsed = time.time() - self.started
            snapshot = self.snapshot()
            listeners = list(self.listeners)
        for q in listeners:
            try:
                q.put_nowait(snapshot)
            except Exception:
                pass

    def snapshot(self):
        return {
            "id": self.id,
            "state": self.state,
            "progress": round(self.progress, 4),
            "message": self.message,
            "elapsed": round(self.elapsed, 2),
            "url": (f"/api/result/{self.id}" if self.state == "done" else None),
            "error": self.error,
            "detail": (self.detail or "")[:600] if self.detail else None,
            **self.meta,
        }

    def subscribe(self):
        q = queue.Queue(maxsize=64)
        with self.lock:
            self.listeners.append(q)
            q.put_nowait(self.snapshot())
            if self.state in ("done", "error", "cancelled"):
                q.put_nowait(None)
        return q

    def unsubscribe(self, q):
        with self.lock:
            if q in self.listeners:
                self.listeners.remove(q)


class Engine:
    """Loads one model at a time, keeps it warm, and runs jobs from a FIFO queue."""

    def __init__(self, args):
        self.args = args
        self.jobs = {}
        self.lock = threading.Lock()
        self.pipe = None
        self.loaded_id = None
        self.loading_id = None
        self.device = "cpu"
        self.gpu_name = None
        self.vram = None
        self.torch = None
        self.torch_version = None
        self.log = []
        self.modelscope = False
        self.lora_active = False
        self.lora_note = ""
        # Which adapters are attached to the currently loaded pipeline, so a job
        # that asks for the same set does not re-attach (and so a job that asks
        # for a different set detaches the old ones first — two adapters of the
        # same kind stacked on each other is a mess nobody asked for).
        self.lora_key = ""
        self.lora_attached = []
        self.extra_loras = [t for t in (getattr(args, "lora", "") or "").split(",") if t.strip()]
        self.lora_active = not getattr(args, "no_lora", False)
        self._job = None
        # Where the weights live, and how to get them (ModelScope first).
        self.weights = Weights(args, self.say)
        self.queue = queue.Queue()
        self.worker = threading.Thread(target=self._loop, daemon=True)
        self.worker.start()

    # -- logging ----------------------------------------------------------- #
    def say(self, text, level="info"):
        line = f"[{time.strftime('%H:%M:%S')}] {text}"
        self.log.append(line)
        del self.log[:-200]
        print(("!! " if level == "warn" else "") + line, flush=True)

    # -- environment ------------------------------------------------------- #
    def detect(self):
        try:
            import torch

            self.torch = torch
            self.torch_version = torch.__version__
            if torch.cuda.is_available():
                self.device = "cuda"
                try:
                    self.gpu_name = torch.cuda.get_device_name(0)
                except Exception:
                    self.gpu_name = "CUDA GPU"
                try:
                    self.vram = round(torch.cuda.get_device_properties(0).total_memory / 1e9, 1)
                except Exception:
                    self.vram = None
            elif getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
                self.device = "mps"
                self.gpu_name = "Apple GPU (MPS)"
            else:
                self.device = "cpu"
        except Exception as e:  # torch missing entirely
            self.say(f"torch not available yet: {e}", "warn")
        self.modelscope = have_module("modelscope")

    # -- model loading ----------------------------------------------------- #
    def load(self, model_id):
        if self.loaded_id == model_id and self.pipe is not None:
            return self.pipe
        spec = MODEL_BY_ID.get(model_id)
        if not spec:
            raise ValueError(f"unknown model '{model_id}'")
        self.loading_id = model_id
        try:
            return self._load(spec)
        finally:
            self.loading_id = None

    def _load(self, spec):
        import diffusers
        import torch

        self.say(f"loading {spec['label']} ({spec['repo']}) …")
        cls = getattr(diffusers, spec["pipeline"], None)
        if cls is None:
            have = [n for n in dir(diffusers) if n.endswith("Pipeline")]
            raise RuntimeError(
                f"this diffusers build ({diffusers.__version__}) has no {spec['pipeline']}. "
                f"Try: pip install -U diffusers  (video pipelines present: "
                f"{', '.join(sorted(have)[:14])}…)"
            )
        dtype = resolve_dtype(torch, spec, self.args.dtype)

        kwargs = {}
        # diffusers renamed torch_dtype -> dtype in 2025; support both.
        try:
            pipe = cls.from_pretrained(spec["repo"], dtype=dtype, **kwargs)
        except TypeError:
            pipe = cls.from_pretrained(spec["repo"], torch_dtype=dtype, **kwargs)

        offload = self.args.offload
        if offload is None:
            offload = self.device == "cuda" and (self.vram or 0) < spec["vramGb"]
        if offload and hasattr(pipe, "enable_model_cpu_offload"):
            try:
                pipe.enable_model_cpu_offload()
                self.say("model CPU offload enabled (lower VRAM, slower)")
            except Exception as e:
                self.say(f"could not enable cpu offload: {e}", "warn")
        else:
            pipe = pipe.to(self.device)

        for opt in ("enable_vae_slicing", "enable_vae_tiling"):
            try:
                getattr(pipe, opt)()
            except Exception:
                pass
        try:
            pipe.set_progress_bar_config(disable=True)
        except Exception:
            pass

        self.pipe = pipe
        self.loaded_id = spec["id"]
        self.lora_key = ""
        self.lora_attached = []
        self.lora_note = ""
        self.say(f"{spec['label']} ready on {self.device} ({dtype})")
        return pipe

    # -- LoRA --------------------------------------------------------------- #
    def lora_public(self):
        """The adapter catalogue as the app sees it, with what is already on disk."""
        out = []
        for entry in LORAS:
            cached = self.weights.peek(entry["repo"], f"lora:{entry['id']}")
            out.append(
                {
                    "id": entry["id"],
                    "label": entry["label"],
                    "repo": entry["repo"],
                    "note": entry["note"],
                    "sizeGb": entry.get("sizeGb"),
                    "steps": entry.get("steps"),
                    "guidance": entry.get("guidance"),
                    "preset": bool(entry.get("preset")),
                    "cached": bool(cached),
                }
            )
        return out

    def lora_entries(self, spec, req):
        """Which adapters this job wants, the bundled distillation one first.

        A request may name them (`"loras": ["nsfw", "motion"]`, or `"lora": "nsfw"`),
        the server may have been started with `--lora <id>` (which applies to every
        job), and a model with a bundled distillation adapter always gets that.
        `"lora": "none"` (or `false`) on the request drops *everything* for that
        job, and `--no-lora` on the server stops the bundled one being added by
        default without disabling adapters that were asked for by name.
        """
        if str(req.get("lora") or "").lower() in ("none", "off", "no"):
            return []
        wanted = req.get("loras")
        if isinstance(wanted, str):
            wanted = [w.strip() for w in wanted.split(",") if w.strip()]
        if not isinstance(wanted, list):
            wanted = []
        if isinstance(req.get("lora"), str) and req["lora"].lower() not in ("", "auto"):
            wanted = [req["lora"]] + wanted
        tokens = list(dict.fromkeys([str(t).strip() for t in self.extra_loras + [str(w) for w in wanted] if str(t).strip()]))
        entries = []
        preset = spec.get("lora") or {}
        if self.lora_active and preset.get("repo"):
            entry = {
                "id": f"distill:{spec['id']}",
                "label": preset.get("note") or "distillation adapter",
                "repo": preset["repo"],
                "ms": preset.get("ms"),
                "files": list(preset.get("files") or []),
                "sizeGb": preset.get("sizeGb"),
                "steps": preset.get("steps"),
                "guidance": preset.get("guidance"),
            }
            entries.append(entry)
        for token in tokens:
            known = LORA_BY_ID.get(token)
            if known:
                entries.append(known)
                continue
            # A repo id, a local folder, or repo:filename — for anything that is
            # not in the catalogue above.
            repo, _, filename = token.partition(":")
            entries.append(
                {
                    "id": f"custom:{token}",
                    "label": repo.rstrip("/").split("/")[-1],
                    "repo": repo,
                    "ms": repo,
                    "files": [filename] if filename else None,
                    "note": "added by hand",
                }
            )
        return entries

    def fetch_lora(self, entry, job=None):
        """Download an adapter if it is not cached, and return (folder, files)."""
        folder = self.weights.fetch(
            entry["repo"],
            ms_id=entry.get("ms"),
            paths=list(entry.get("files") or []) or None,
            size_gb=entry.get("sizeGb"),
            job=job,
            tag=f"lora:{entry['id']}",
            label=f"{entry['label']} LoRA",
        )
        if os.path.isdir(folder):
            explicit = [os.path.join(folder, f) for f in (entry.get("files") or [])]
            explicit = [f for f in explicit if os.path.exists(f)]
            return folder, (explicit or safetensor_files(folder))
        # A local folder given by hand (`--lora /path/to/adapter`).
        return folder, safetensor_files(folder)

    def detach_loras(self, pipe):
        """Take whatever the previous job attached back off."""
        if not self.lora_attached:
            self.lora_key = ""
            return
        try:
            pipe.unload_lora_weights()
        except Exception:
            pass
        for comp in ("transformer", "transformer_2", "unet"):
            module = getattr(pipe, comp, None)
            if module is None:
                continue
            for name in list(self.lora_attached):
                try:
                    module.delete_adapters(name)
                except Exception:
                    pass
        self.lora_attached = []
        self.lora_key = ""

    def _attach_files(self, pipe, pairs, component):
        """Attach (adapter name, safetensors path) pairs to one component.

        Component first — that is precisely what the two-expert Wan 2.2 needs,
        because each half belongs to one transformer — then the pipeline-level
        API, which sorts the adapter's keys by their prefix and puts them where
        they belong. Every file gets its *own* adapter name: stacking two
        adapters that share one name would have the second replace the first.
        Returns the names that were loaded.
        """
        pairs = [(name, path) for name, path in (pairs or []) if os.path.exists(path)]
        if not pairs:
            return []
        target = getattr(pipe, component, None) if component else pipe
        loaded, last = [], None
        for name, path in pairs:
            done = False
            if target is not None:
                try:
                    target.load_lora_adapter(path, adapter_name=name)
                    done = True
                except Exception as e:
                    last = e
            if not done:
                try:
                    pipe.load_lora_weights(
                        os.path.dirname(path),
                        weight_name=os.path.basename(path),
                        adapter_name=name,
                    )
                    done = True
                except Exception as e:
                    last = e
            if done:
                loaded.append(name)
        if not loaded:
            self.say(f"could not attach {os.path.basename(pairs[0][1])}: {last}", "warn")
        return loaded

    def _arm_adapters(self, pipe, names):
        """Make every loaded adapter active at once, component by component.

        `pipe.set_adapters(names)` is the tidy call, but it checks the names
        against the *pipeline's* own bookkeeping — which is empty when the
        adapters were loaded onto a transformer by hand — so each component that
        actually carries one of the names is armed directly, and the
        pipeline-level call is only the fallback. Returns the names that are
        known to be active; anything missing is reported, because an adapter
        that loaded but never got armed does nothing at all.
        """
        names = [n for n in names if n]
        if not names:
            return []
        done = set()
        for comp in ("transformer", "transformer_2", "unet"):
            module = getattr(pipe, comp, None)
            if module is None:
                continue
            have = getattr(module, "peft_config", None)
            mine = [n for n in names if not have or n in have]
            if not mine:
                continue
            for method in ("set_adapter", "set_adapters"):
                fn = getattr(module, method, None)
                if fn is None:
                    continue
                try:
                    fn(mine)
                    done.update(mine)
                    break
                except Exception as e:
                    self.say(f"{method}({mine}) on {comp}: {e}", "warn")
        missing = [n for n in names if n not in done]
        if missing:
            try:
                pipe.set_adapters(names)
                done.update(missing)
            except Exception as e:
                self.say(f"adapters {missing} could not be armed: {e}", "warn")
        return sorted(done)

    def ensure_loras(self, pipe, spec, entries, job=None):
        """Make the attached adapters match `entries` exactly, then arm them."""
        key = "|".join(e["id"] for e in entries)
        if key == self.lora_key:
            return self.lora_note
        self.detach_loras(pipe)
        if not entries:
            self.lora_key = key
            self.lora_note = ""
            return ""
        notes = []
        attached = []
        for entry in entries:
            if job is not None:
                job.emit(message=f"preparing the {entry['label']} adapter…")
            try:
                folder, files = self.fetch_lora(entry, job=job)
            except Exception as e:
                self.say(f"{entry['label']} adapter could not be fetched: {e}", "warn")
                continue
            if not files:
                self.say(f"no .safetensors found for {entry['label']} in {folder}", "warn")
                continue
            base = "".join(c if c.isalnum() else "_" for c in str(entry["id"])) or "lora"
            named = [(f"{base}_{i}", path) for i, path in enumerate(files)]
            high, low = split_experts([path for _n, path in named])
            by_path = {path: name for name, path in named}
            two_experts = getattr(pipe, "transformer_2", None) is not None
            if two_experts and high and low:
                # Each half belongs to its own expert — this is the whole point of
                # the A14B pair, so both calls have to actually run. (`a or b`
                # here would quietly drop the low-noise half, because the first
                # call returns a non-empty list when it succeeds.)
                first = self._attach_files(pipe, [(by_path[p], p) for p in high], "transformer")
                second = self._attach_files(pipe, [(by_path[p], p) for p in low], "transformer_2")
                loaded = first + second
                strategy = f"component:transformer{'+transformer_2' if first and second else ''}"
            elif two_experts and high:
                loaded = self._attach_files(pipe, [(by_path[p], p) for p in high], "transformer")
                strategy = "component:transformer"
            else:
                # One transformer: the high half is the one that carries the
                # adapter's keys, and a second half would be overwritten by
                # whichever loaded last.
                chosen = high or [path for _n, path in named]
                loaded = self._attach_files(pipe, [(by_path[p], p) for p in chosen], None)
                strategy = "pipeline"
            if not loaded:
                continue
            attached.extend(loaded)
            notes.append(f"{entry['label']} ({os.path.basename(files[0])})")
            self.say(
                f"LoRA {entry['id']} attached via {strategy}: "
                f"{', '.join(os.path.basename(f) for f in files[:4])}"
            )
        armed = self._arm_adapters(pipe, attached)
        if attached and not armed:
            self.say("the adapters loaded but none could be armed — this job runs the base model", "warn")
        elif armed and len(armed) < len(attached):
            self.say(f"{len(attached) - len(armed)} adapter(s) did not arm; running with {armed}", "warn")
        elif not attached:
            self.say("no adapter could be attached — running the base model for this job", "warn")
        # A job that attached nothing still records its key, so the same
        # (failing) set is not re-downloaded and re-tried on every render.
        self.lora_attached = armed
        self.lora_key = key
        self.lora_note = " · ".join(notes) if armed else ""
        return self.lora_note

    # -- request → pipeline kwargs ----------------------------------------- #
    @staticmethod
    def decode_image(raw, what="reference image"):
        if not raw:
            return None
        if isinstance(raw, str) and raw.startswith("data:"):
            raw = raw.split(",", 1)[1]
        try:
            data = base64.b64decode(raw)
        except (binascii.Error, ValueError) as e:
            raise ValueError(f"could not decode the {what}: {e}")
        from PIL import Image

        img = Image.open(io.BytesIO(data)).convert("RGB")
        return img

    def build_image(self, req, key="image"):
        return self.decode_image(req.get(key))

    @staticmethod
    def fps_plan(spec, req):
        """(render fps, delivered fps) for one request.

        A model renders at one rate and cannot be asked for another: Wan is
        trained at 16 fps, LTX at 24. A request for a *higher* rate therefore
        renders at the model's own rate and is interpolated up afterwards (real
        frames, with the motion between them estimated), while a request for a
        lower one simply renders fewer frames. Asking a 14B model for 48 fps
        outright would mean three times the frames, three times the render time,
        and a likely OOM — the render rate is capped at the model's own.
        `interpolate: false` (or 0) keeps the delivered clip at the render rate.
        """
        native = int(spec.get("fps") or 24)
        try:
            want = int(req.get("fps") or 0)
        except (TypeError, ValueError):
            want = 0
        render = max(1, min(want or native, native))
        target = want or native
        opt = req.get("interpolate")
        if opt is False or opt == 0:
            target = render
        elif isinstance(opt, (int, float)):
            target = int(opt)
        if target <= render:
            target = render
        return render, target

    def call_kwargs(self, spec, req, image, torch, steps, guidance=None):
        w = max(256, min(1280, int(req.get("width") or self.args.width)))
        h = max(256, min(1280, int(req.get("height") or self.args.height)))
        w -= w % 16
        h -= h % 16
        # A 14B model trained at 720p invents mush when you ask it for 480p — the
        # biggest quality lever on this server is simply running each model at the
        # resolution it was trained at. Models that have a native resolution above
        # the requested one are scaled up to it (send {"native": false} to opt out).
        native = int(spec.get("native") or 0)
        if native and max(w, h) < native and req.get("native") is not False:
            scale = native / float(max(w, h))
            w = max(256, int(round(w * scale)))
            h = max(256, int(round(h * scale)))
            w -= w % 16
            h -= h % 16
        fps = self.fps_plan(spec, req)[0]
        duration = float(req.get("duration") or min(4.0, spec["maxSec"]))
        duration = max(spec["minSec"], min(spec["maxSec"], duration))
        frames = align_frames(round(duration * fps), spec["frameStep"])
        seed = req.get("seed")
        generator = torch.Generator(device="cpu").manual_seed(
            int(seed) if seed is not None else int(time.time() * 1000) % 2**31
        )

        kw = {
            "prompt": req.get("prompt") or "",
            "negative_prompt": req.get("negative") or None,
            "width": w,
            "height": h,
            "num_frames": frames,
            "num_inference_steps": steps,
            "guidance_scale": float(
                guidance if guidance is not None else (req.get("guidance") or spec["guidance"])
            ),
            "generator": generator,
            "output_type": "np" if spec["family"].startswith(("wan", "cog")) else "pil",
        }
        if image is not None:
            kw["image"] = image
        # First/last-frame models take a second image; the web app sends it as
        # `lastImage`, and the argument is dropped if the installed pipeline has
        # no use for it.
        if image is not None and spec["caps"].get("endFrame"):
            last = self.build_image(req, "lastImage")
            if last is not None:
                kw["last_image"] = last
        if spec["family"] == "svd":
            kw["decode_chunk_size"] = 4
            kw["num_frames"] = min(frames, 25)
            kw["motion_bucket_id"] = max(20, min(255, int(round(float(req.get("motion") or 1.0) * 127))))
            kw["noise_aug_strength"] = 0.02
            kw["fps"] = fps
            kw["output_type"] = "pil"
            kw.pop("negative_prompt", None)
        if spec["family"] == "ltx":
            # LTX calls its frame rate `frame_rate`, and needs 32-pixel multiples.
            kw["frame_rate"] = fps
            kw.pop("fps", None)
            kw["height"] = h - (h % 32)
            kw["width"] = w - (w % 32)
        return kw

    # -- generation -------------------------------------------------------- #
    def generate(self, job):
        req = job.req
        spec = MODEL_BY_ID.get(req.get("model") or self.args.model)
        if spec is None:
            raise ValueError("no model selected")
        job.emit(state="loading", progress=0.02, message=f"loading {spec['label']}…")
        t0 = time.time()
        pipe = self.load(spec["id"])
        dtype = resolve_dtype(self.torch, spec, self.args.dtype) if self.torch else None
        image = self.build_image(req) if spec["caps"]["i2v"] else None
        if image is None and not spec["caps"]["t2v"]:
            raise ValueError("this model needs a reference image")

        # Adapters first. The distillation LoRA is what makes a 14B model usable
        # at 4 steps instead of 40, and a content adapter is what lets the model
        # draw what was asked for at all. Both have to be *attached* before the
        # pipeline is called — the catalogue used to name them and never load
        # them, which is why a 4-step recipe ran 30 steps with no adapter and
        # produced a near-still frame.
        entries = self.lora_entries(spec, req)
        lora_note = self.ensure_loras(pipe, spec, entries, job=job)
        if req.get("nsfw") and self.lora_active and not any("nsfw" in e["id"] for e in entries):
            self.say(
                "an explicit clip was requested without a content adapter — a base "
                'checkpoint will only hint at it (ask for one with "loras": ["nsfw"], '
                "or start the server with --lora nsfw)",
                "warn",
            )
        lora_steps = next((e.get("steps") for e in entries if e.get("steps")), None)
        lora_guide = next((e.get("guidance") for e in entries if e.get("guidance") is not None), None)
        steps = int(req.get("steps") or lora_steps or spec["steps"])
        guidance = float(req.get("guidance") or lora_guide or spec["guidance"])
        kwargs = self.call_kwargs(spec, req, image, self.torch, steps, guidance)
        frames = kwargs["num_frames"]
        fps, want_fps = self.fps_plan(spec, req)

        # Only pass arguments the installed pipeline actually accepts, and hook progress.
        import inspect

        accepted = set(inspect.signature(pipe.__call__).parameters)
        has_cb = "callback_on_step_end" in accepted

        def on_step(pipe_, step, timestep, cb_kwargs):
            if job.cancel.is_set():
                raise RuntimeError("__cancelled__")
            frac = (step + 1) / max(1, steps)
            job.emit(
                state="running",
                progress=0.05 + 0.85 * frac,
                message=f"denoising step {step + 1}/{steps} · {frames} frames @ {fps}fps",
            )
            return cb_kwargs

        if has_cb:
            kwargs["callback_on_step_end"] = on_step
        kwargs = {k: v for k, v in kwargs.items() if k in accepted and v is not None}

        lora_txt = f" · {lora_note}" if lora_note else ""
        job.emit(
            state="running",
            progress=0.05,
            message=(
                f"{spec['label']}{lora_txt} · {kwargs.get('width')}×{kwargs.get('height')}"
                f" · {frames} frames"
            ),
        )
        self.say(
            f"job {job.id}: {spec['id']} {kwargs.get('width')}×{kwargs.get('height')} "
            f"{frames}f steps={steps} guidance={guidance}"
        )
        result = pipe(**kwargs)
        if job.cancel.is_set():
            raise RuntimeError("__cancelled__")

        frames_out = result.frames[0]
        job.emit(state="encoding", progress=0.92, message="encoding mp4…")
        path = os.path.join(self.args.out, f"{job.id}.mp4")
        write_mp4(frames_out, path, fps)

        # A frame rate the model cannot render at is reached by interpolation
        # rather than by a label on the file. ffmpeg estimates the motion between
        # two frames and draws the frames in between, so "48 fps" means 48 real
        # frames per second instead of a 16 fps clip that claims to be 48.
        out_fps = fps
        if want_fps > fps:
            job.emit(state="encoding", progress=0.95, message=f"interpolating {fps} → {want_fps} fps…")
            smoother = os.path.join(self.args.out, f"{job.id}-{want_fps}fps.mp4")
            got = interpolate_video(path, smoother, want_fps)
            if got != path:
                path = got
                out_fps = want_fps
                job.emit(message=f"frame rate raised to {want_fps} fps")
            else:
                self.say("could not interpolate (imageio-ffmpeg missing?) — keeping the model's own rate", "warn")

        import numpy as np

        arr = np.asarray(frames_out[0])
        entry = self.weights.peek(spec["repo"]) or {}
        job.meta = {
            "model": spec["id"],
            "modelLabel": spec["label"],
            "width": int(arr.shape[1]),
            "height": int(arr.shape[0]),
            "frames": len(frames_out),
            "fps": out_fps,
            "interpolated": out_fps != fps,
            "duration": round(len(frames_out) / out_fps, 2),
            "seed": kwargs.get("generator").initial_seed() if kwargs.get("generator") else None,
            "renderSecs": round(time.time() - t0, 1),
            "steps": steps,
            "guidance": guidance,
            "precision": (str(dtype).rsplit(".", 1)[-1] if dtype is not None else (self.args.dtype or "auto")),
            "loras": [e["id"] for e in entries],
            "lora": lora_note or None,
            "source": entry.get("source"),
        }
        job.path = path
        job.emit(state="done", progress=1.0, message=f"done in {job.meta['renderSecs']}s")
        self.say(f"job {job.id} done: {job.meta['width']}×{job.meta['height']} {job.meta['duration']}s")

    # -- worker loop ------------------------------------------------------- #
    def _loop(self):
        while True:
            job = self.queue.get()
            if job.cancel.is_set():
                job.emit(state="cancelled", message="cancelled before it started")
                continue
            self._job = job
            try:
                job.emit(state="running", message="starting…")
                if job.req.get("download"):
                    self.download(job)
                else:
                    self.generate(job)
            except Exception as e:
                if "__cancelled__" in str(e) or job.cancel.is_set():
                    job.emit(state="cancelled", message="cancelled")
                else:
                    tb = traceback.format_exc()
                    self.say(f"job {job.id} failed: {e}\n{tb}", "warn")
                    job.emit(state="error", error=human_error(e), detail=str(e))
            finally:
                self._job = None
                self.queue.task_done()

    def _enqueue(self, req):
        job = Job(req)
        self.jobs[job.id] = job
        # keep the job table small
        if len(self.jobs) > 40:
            for k in sorted(self.jobs, key=lambda k: self.jobs[k].started)[:10]:
                old = self.jobs.pop(k, None)
                if old and old.path and os.path.exists(old.path):
                    try:
                        os.remove(old.path)
                    except Exception:
                        pass
        self.queue.put(job)
        return job

    def submit(self, req):
        return self._enqueue(req)

    def start_download(self, model_id, part="main"):
        spec = MODEL_BY_ID.get(model_id)
        if not spec:
            raise ValueError(f"unknown model '{model_id}'")
        return self._enqueue({"download": True, "model": model_id, "part": part})

    # -- weight downloads -------------------------------------------------- #
    def download(self, job):
        """Fetch a model's files ahead of time (same queue, same progress events)."""
        spec = MODEL_BY_ID.get(job.req.get("model"))
        if spec is None:
            raise ValueError("no model selected")
        label = spec["label"]
        job.emit(state="downloading", progress=0.02, message=f"checking the {label} files…")
        self.local_weights(spec, job=job)
        # The adaptation the job would use — the model's bundled distillation
        # adapter plus anything named by `--lora` on the server or in the
        # request. Downloading them here means the first render does not stall
        # halfway through a multi-GB fetch.
        for entry in self.lora_entries(spec, job.req):
            job.emit(message=f"checking the {entry['label']} adapter…")
            try:
                self.fetch_lora(entry, job=job)
            except Exception as e:
                self.say(f"{entry['label']} adapter could not be fetched: {e}", "warn")
        entry = self.weights.peek(spec["repo"]) or {}
        gb = entry.get("gb")
        tail = f" — {gb:g} GB on disk" if gb else ""
        job.emit(state="done", progress=1.0, message=f"{label} is ready{tail}")
        self.say(f"weights ready: {spec['id']}{tail}")

    # -- catalogue --------------------------------------------------------- #
    def model_public(self, spec):
        entry = self.weights.peek(spec["repo"]) or {}
        lora = spec.get("lora") or {}
        return {
            "id": spec["id"],
            "label": spec["label"],
            "repo": spec["repo"],
            "ms": spec.get("ms"),
            "family": spec.get("family"),
            "fps": spec["fps"],
            "minSec": spec["minSec"],
            "maxSec": spec["maxSec"],
            "vramGb": spec["vramGb"],
            "sizeGb": spec.get("sizeGb"),
            "native": spec.get("native"),
            "caps": spec["caps"],
            "note": spec["note"],
            "lora": lora.get("note"),
            "cached": bool(entry.get("path")),
            "cachedGb": entry.get("gb"),
            "source": entry.get("source"),
            "loaded": self.loaded_id == spec["id"],
        }

    def weights_info(self):
        return {
            "ok": True,
            "root": self.weights.root,
            "source": self.args.source,
            "hfEndpoint": self.args.hf_endpoint or None,
            "precision": self.args.dtype or "auto",
            "modelscope": self.modelscope,
            "offline": bool(self.args.offline),
            "loras": self.lora_public(),
            "index": [
                {
                    "repo": e.get("repo"),
                    "tag": k.split("#", 1)[1] if "#" in k else "main",
                    "source": e.get("source"),
                    "repoId": e.get("repo_id"),
                    "gb": e.get("gb"),
                    "at": e.get("at"),
                    "path": e.get("path"),
                }
                for k, e in sorted(self.weights.index.items())
            ],
            "models": [self.model_public(m) for m in MODELS],
        }

    def busy(self):
        if self.queue.qsize() > 0:
            return True
        return any(
            j.state in ("running", "loading", "encoding", "downloading") for j in self.jobs.values()
        )

    def health(self):
        return {
            "ok": True,
            "server": SERVER_NAME,
            "version": VERSION,
            "device": self.device,
            "gpu": self.gpu_name,
            "vramGb": self.vram,
            "torch": self.torch_version,
            "python": platform.python_version(),
            "busy": self.busy(),
            "queued": self.queue.qsize(),
            "loaded": self.loaded_id,
            "loading": self.loading_id,
            "lora": self.lora_note or None,
            "loraActive": self.lora_active,
            "loras": self.lora_public(),
            "precision": self.args.dtype or "auto",
            "modelscope": self.modelscope,
            "weightsRoot": self.weights.root,
            "source": self.args.source,
            "hfEndpoint": self.args.hf_endpoint or None,
            "offline": bool(self.args.offline),
            "cached": [m["id"] for m in MODELS if self.weights.peek(m["repo"])],
            "models": [self.model_public(m) for m in MODELS],
            "defaultModel": self.args.model if self.args.model in MODEL_BY_ID else MODELS[0]["id"],
        }

def human_error(e):
    s = str(e)
    low = s.lower()
    if "out of memory" in low:
        return "The GPU ran out of memory. Try a lower resolution, a shorter clip, or the 'svd' model."
    if "modelscope' package is not installed" in low or "no module named 'modelscope'" in low:
        return "The ModelScope package is missing — run 'pip install modelscope', or start the server with --source hf."
    if "could not download" in low:
        return (
            "Could not download the model weights. Check the connection, then try "
            "'python server.py --download <model>' — or force the mirror with "
            "'--source hf --hf-endpoint https://hf-mirror.com'."
        )
    if "offline mode" in low:
        return "Offline mode is on and those weights are not cached yet — run 'python server.py --weights' to see what is there."
    if "has not been downloaded" in low:
        return "Those weights are not on disk yet — fetch them first with 'python server.py --download <model>'."
    if "no module named" in low:
        return f"A Python package is missing: {s}. Re-run the install cell."
    if "401" in s or "403" in s or "gated" in low:
        return "This model needs you to accept its licence on Hugging Face (or is gated)."
    if "connection" in low or "resolve" in low:
        return "Could not download the model weights — check the internet connection."
    return s[:400]

def write_mp4(frames, path, fps):
    """Save frames (numpy arrays or PIL images) as an H.264 mp4."""
    import numpy as np

    try:
        import imageio.v3 as iio

        arr = np.stack([np.asarray(f).astype("uint8") for f in frames])
        iio.imwrite(path, arr, fps=fps, codec="libx264", quality=8, macro_block_size=1)
        return
    except Exception:
        pass
    try:
        from diffusers.utils import export_to_video

        export_to_video(frames, path, fps=fps)
        return
    except Exception as e:
        raise RuntimeError(f"could not encode the video: {e}")


# --------------------------------------------------------------------------- #
#  HTTP layer (FastAPI).  Everything is JSON + SSE so the browser could not care
#  less what framework this is.
# --------------------------------------------------------------------------- #
def build_app(engine):
    from fastapi import Body, FastAPI, Request
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, StreamingResponse

    # The web app can send its model requests through this process, so the model
    # sees this machine's address instead of the visitor's. Deliberately narrow:
    # only the hosts the app genuinely talks to are forwardable, and only the
    # three methods it uses. It is a relay, not an open proxy.
    relay_allowed = (
        "huggingface.co",  # the per-space JWT endpoint
        "hf.space",        # the Spaces themselves (the job request, and uploads)
        "hf.co",
        "pollinations.ai",  # the free starting-frame image service
        "ipify.org",        # "what address do I look like?" self-checks
        "ifconfig.me",
        "cloudflare.com",   # ... and the same check through Cloudflare's trace
        # The paid vendors are models too, so their API traffic is relayed as
        # well when the app is in private mode.
        "replicate.com",
        "replicate.delivery",  # where Replicate parks the finished clip
        "fal.run",
        "fal.media",           # where fal.ai parks the finished clip
        "runwayml.com",
    )
    relay_max_body = 16 * 1024 * 1024
    relay_timeout = 180

    app = FastAPI(title="AIVideoGen Server", version=str(VERSION))
    # The web app runs on a different origin (https://<id>.perchance.org), and a local
    # server runs on http://127.0.0.1 — both need to be allowed.
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["*"],
    )

    @app.middleware("http")
    async def gate(request: Request, call_next):
        """Optional shared key, for when the server is exposed on a LAN or a tunnel."""
        if engine.args.key and request.url.path.startswith("/api/"):
            # Prefer the header (URLs land in tunnel/server access logs); the
            # query key stays only because EventSource cannot set headers.
            given = request.headers.get("x-api-key") or request.query_params.get("key") or ""
            if not hmac.compare_digest(str(given), str(engine.args.key)):
                return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=401)
        return await call_next(request)

    @app.get("/api/health")
    def health():
        return JSONResponse(engine.health())

    @app.get("/api/models")
    def models():
        return JSONResponse(engine.health()["models"])

    @app.get("/api/weights")
    def weights_info():
        return JSONResponse(engine.weights_info())

    @app.post("/api/weights/download")
    async def weights_download(req: Request):
        body = await req.json()
        mid = body.get("model")
        if mid not in MODEL_BY_ID:
            return JSONResponse({"ok": False, "error": f"unknown model '{mid}'"}, status_code=400)
        if engine.busy():
            return JSONResponse({"ok": False, "error": "busy", "queued": engine.queue.qsize()}, status_code=409)
        job = engine.start_download(mid, str(body.get("part") or "main"))
        return {"ok": True, "job": job.id, "state": job.state, "health": engine.health()}

    @app.post("/api/weights/remove")
    async def weights_remove(payload: dict = Body(...)):
        mid = payload.get("model")
        spec = MODEL_BY_ID.get(mid)
        if not spec:
            return JSONResponse({"ok": False, "error": f"unknown model '{mid}'"}, status_code=400)
        if payload.get("confirm") != "remove":
            return JSONResponse(
                {"ok": False, "error": 'pass {"confirm": "remove"} to really delete these files'},
                status_code=400,
            )
        if engine.loaded_id == mid and engine.pipe is not None:
            return JSONResponse(
                {"ok": False, "error": "that model is loaded — load another one first, then remove it"},
                status_code=409,
            )
        freed = engine.weights.remove(spec["repo"])
        lora = spec.get("lora") or {}
        if lora.get("repo"):
            freed += engine.weights.remove(lora["repo"], tag="lora")
        return {"ok": True, "freedGb": round(freed / 1e9, 2), "health": engine.health()}

    @app.get("/api/log")
    def log():
        return JSONResponse({"log": engine.log[-120:]})

    @app.post("/api/relay")
    def relay(payload: dict = Body(...)):
        """Forward one request to an allow-listed host and hand the answer back.

        The web app uses this to give each generation a different egress address
        (see "Privacy & IP rotation" in Settings). """
        from urllib import error as urlerror
        from urllib import parse as urlparse
        from urllib import request as urlrequest

        url = str(payload.get("url") or "")
        method = str(payload.get("method") or "GET").upper()
        extra = payload.get("headers") or {}
        data = payload.get("body")
        body_b64 = payload.get("bodyB64")
        content_type = str(payload.get("contentType") or "")

        parts = urlparse.urlparse(url)
        host = (parts.hostname or "").lower()
        if parts.scheme not in ("http", "https") or not host:
            return JSONResponse({"ok": False, "error": "bad url"}, status_code=400)
        if not any(host == h or host.endswith("." + h) for h in relay_allowed):
            return JSONResponse({"ok": False, "error": f"this relay does not forward {host}"}, status_code=403)
        if method not in ("GET", "POST", "HEAD"):
            return JSONResponse({"ok": False, "error": "method not allowed"}, status_code=405)

        # A multipart (or any binary) body cannot arrive as JSON text, so the
        # browser re-encodes it; `contentType` carries the exact header the
        # browser would have sent, boundary and all.
        blob = None
        if isinstance(body_b64, str) and body_b64:
            try:
                blob = base64.b64decode(body_b64)
            except (binascii.Error, ValueError):
                return JSONResponse({"ok": False, "error": "bad bodyB64"}, status_code=400)
        elif isinstance(data, str):
            blob = data.encode("utf-8")
        if blob is not None and len(blob) > relay_max_body:
            return JSONResponse({"ok": False, "error": "body too large"}, status_code=413)

        rq = urlrequest.Request(url, data=blob, method=method)
        sent_ua = False
        for k, v in (extra or {}).items():
            if not isinstance(k, str) or not isinstance(v, (str, int, float)):
                continue
            low = k.lower()
            if low in ("host", "content-length", "connection", "accept-encoding"):
                continue
            if low == "content-type" and content_type:
                continue
            rq.add_header(k, str(v))
            if low == "user-agent":
                sent_ua = True
        if content_type:
            rq.add_header("Content-Type", content_type)
        if not sent_ua:
            rq.add_header("User-Agent", "Mozilla/5.0 (compatible; AIVideoGen-relay/1.0)")

        try:
            with urlrequest.urlopen(rq, timeout=relay_timeout) as r:
                raw = r.read(relay_max_body)
                status = r.status
                headers = dict(r.headers.items())
        except urlerror.HTTPError as e:
            raw = e.read(relay_max_body) if e.fp else b""
            status = e.code
            headers = dict(e.headers.items()) if e.headers else {}
        except Exception as e:
            return JSONResponse({"ok": False, "error": f"relay could not reach {host}: {e}"}, status_code=502)

        keep = {
            k: v
            for k, v in headers.items()
            if k.lower() in ("content-type", "content-length", "location", "x-error-message", "x-error-code")
        }
        return {"ok": True, "status": status, "headers": keep, "body": raw.decode("utf-8", "replace")}

    @app.get("/api/relay/raw")
    def relay_raw(url: str = ""):
        """Stream one allow-listed GET straight back to the caller.

        `/api/relay` reads the whole answer into JSON, which is fine for a small
        JSON reply but destroys a video file and stalls a live progress stream —
        so the two requests that are not small use this instead. The bytes are
        handed over as they arrive, and the content-type comes with them, which
        is what makes a Server-Sent Events stream keep flowing."""
        from urllib import error as urlerror
        from urllib import parse as urlparse
        from urllib import request as urlrequest

        parts = urlparse.urlparse(url)
        host = (parts.hostname or "").lower()
        if parts.scheme not in ("http", "https") or not host:
            return JSONResponse({"ok": False, "error": "bad url"}, status_code=400)
        if not any(host == h or host.endswith("." + h) for h in relay_allowed):
            return JSONResponse({"ok": False, "error": f"this relay does not forward {host}"}, status_code=403)

        rq = urlrequest.Request(url, method="GET")
        rq.add_header("User-Agent", "Mozilla/5.0 (compatible; AIVideoGen-relay/1.0)")
        upstream = None
        try:
            upstream = urlrequest.urlopen(rq, timeout=relay_timeout)
        except urlerror.HTTPError as e:
            upstream = e
        except Exception as e:
            return JSONResponse({"ok": False, "error": f"relay could not reach {host}: {e}"}, status_code=502)

        def pump():
            try:
                while True:
                    chunk = upstream.read(65536)
                    if not chunk:
                        break
                    yield chunk
            finally:
                try:
                    upstream.close()
                except Exception:
                    pass

        try:
            ctype = upstream.headers.get("content-type") or ""
        except Exception:
            ctype = ""
        headers = {"Cache-Control": "no-store"}
        if ctype:
            headers["Content-Type"] = ctype
        return StreamingResponse(pump(), status_code=getattr(upstream, "status", 200) or 200, headers=headers)

    @app.post("/api/load")
    async def load(req: Request):
        body = await req.json()
        mid = body.get("model")
        if mid not in MODEL_BY_ID:
            return JSONResponse({"ok": False, "error": "unknown model"}, status_code=400)
        try:
            engine.load(mid)
        except Exception as e:
            return JSONResponse({"ok": False, "error": human_error(e), "detail": str(e)}, status_code=500)
        return {"ok": True, "loaded": mid, "health": engine.health()}

    @app.post("/api/generate")
    async def generate(req: Request):
        body = await req.json()
        mid = body.get("model")
        if mid not in MODEL_BY_ID:
            return JSONResponse({"ok": False, "error": f"unknown model '{mid}'"}, status_code=400)
        if engine.busy():
            return JSONResponse({"ok": False, "error": "busy", "queued": engine.queue.qsize()}, status_code=409)
        job = engine.submit(body)
        return {"job": job.id, "state": job.state}

    @app.get("/api/status/{job_id}")
    def status(job_id: str, request: Request):
        job = engine.jobs.get(job_id)
        if not job:
            return JSONResponse({"ok": False, "error": "no such job"}, status_code=404)

        def stream():
            q = job.subscribe()
            try:
                while True:
                    if request and _disconnected(request):
                        break
                    try:
                        item = q.get(timeout=15)
                    except queue.Empty:
                        yield ": keep-alive\n\n"
                        continue
                    if item is None:
                        yield f"event: end\ndata: {{}}\n\n"
                        break
                    yield f"event: state\ndata: {json.dumps(item)}\n\n"
            finally:
                job.unsubscribe(q)

        return StreamingResponse(
            stream(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no", "Connection": "keep-alive"},
        )

    @app.get("/api/result/{job_id}")
    def result(job_id: str):
        job = engine.jobs.get(job_id)
        if not job or not job.path or not os.path.exists(job.path):
            return JSONResponse({"ok": False, "error": "result not ready"}, status_code=404)
        return FileResponse(job.path, media_type="video/mp4", filename=f"aivideogen-{job_id}.mp4")

    @app.post("/api/cancel/{job_id}")
    def cancel(job_id: str):
        job = engine.jobs.get(job_id)
        if not job:
            return JSONResponse({"ok": False, "error": "no such job"}, status_code=404)
        job.cancel.set()
        if job.state == "queued":
            job.emit(state="cancelled", message="cancelled")
        return {"ok": True}

    @app.get("/", response_class=HTMLResponse)
    def index():
        h = engine.health()
        def weight_cell(m):
            if m["cached"]:
                gb = m["cachedGb"] or 0
                who = {"ms": "ModelScope", "hf": "Hugging Face"}.get(m["source"], m["source"] or "")
                return f"<span class='ok'>✓ {gb:g} GB</span> <span class='dim'>{who}</span>"
            size = f"~{m['sizeGb']:g} GB" if m["sizeGb"] else "?"
            return f"<span class='dim'>not downloaded ({size})</span>"

        rows = "".join(
            f"<tr><td><code>{m['id']}</code></td><td>{m['label']}</td>"
            f"<td>{m['maxSec']:g}s</td><td>{m['vramGb']}GB</td>"
            f"<td>{weight_cell(m)}</td>"
            f"<td>{'✓' if m['loaded'] else ''}</td></tr>"
            for m in h["models"]
        )
        return f"""<!doctype html><html><head><meta charset="utf-8">
<title>AIVideoGen Server</title>
<style>body{{font:14px/1.5 system-ui,sans-serif;background:#0d1017;color:#dfe4f2;margin:0;padding:32px}}
code{{background:#1b2030;padding:2px 6px;border-radius:4px}}table{{border-collapse:collapse;margin-top:12px}}
.dim{{color:#8b93a8}}
td,th{{padding:6px 14px;border-bottom:1px solid #232a3d;text-align:left}}
.ok{{color:#7ee2a8}}.big{{font-size:20px;font-weight:600}}</style></head><body>
<div class="big">AIVideoGen Server <span class="ok">running</span></div>
<p>device <code>{h['device']}</code> · gpu <code>{h['gpu'] or '—'}</code> ·
vram <code>{h['vramGb'] or '—'} GB</code> · torch <code>{h['torch'] or '—'}</code> ·
python <code>{h['python']}</code> · busy <code>{h['busy']}</code></p>
<p>weights <code>{h['weightsRoot']}</code> · source <code>{h['source']}</code> ·
modelscope <code>{'yes' if h['modelscope'] else 'no'}</code> · offline <code>{h['offline']}</code></p>
<p>Paste this address into the web app's <b>Settings → My GPU server</b> box:
<code id="addr"></code></p>
<script>document.getElementById('addr').textContent = location.origin;</script>
<table><tr><th>id</th><th>model</th><th>one shot</th><th>needs</th><th>weights</th><th>loaded</th></tr>{rows}</table>
<p style="color:#8b93a8">Endpoints: <code>/api/health</code> <code>/api/generate</code>
<code>/api/status/&lt;job&gt;</code> <code>/api/result/&lt;job&gt;</code> <code>/api/cancel/&lt;job&gt;</code>
<code>/api/weights</code></p>
<p style="color:#8b93a8">Fetch weights early: <code>python server.py --download &lt;model&gt;</code></p>
</body></html>"""

    return app


def _disconnected(request):
    try:
        return bool(request and request.client is None)
    except Exception:
        return False


# --------------------------------------------------------------------------- #
#  Cloudflare quick tunnel — a free public https URL with no account.
# --------------------------------------------------------------------------- #
CLOUDFLARED_URLS = {
    "linux-x86_64": "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64",
    "linux-aarch64": "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64",
    "darwin-x86_64": "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-darwin-amd64.tgz",
    "darwin-arm64": "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-darwin-arm64.tgz",
    "windows-amd64": "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe",
}


def start_tunnel(port):
    """Spawn cloudflared and return the public https URL (or None)."""
    exe = shutil.which("cloudflared")
    if not exe:
        key = f"{platform.system().lower()}-{platform.machine().lower()}"
        url = CLOUDFLARED_URLS.get(key)
        if not url:
            print(f"!! no cloudflared download for {key} — install cloudflared manually", flush=True)
            return None
        target = os.path.abspath("cloudflared" + (".exe" if "windows" in key else ""))
        print(f"downloading cloudflared → {target}", flush=True)
        try:
            _download(url, target)
            os.chmod(target, 0o755)
            exe = target
        except Exception as e:
            print(f"!! could not fetch cloudflared: {e}", flush=True)
            return None
    try:
        proc = subprocess.Popen(
            [exe, "tunnel", "--url", f"http://127.0.0.1:{port}", "--no-autoupdate"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
    except Exception as e:
        print(f"!! could not start cloudflared: {e}", flush=True)
        return None

    url_box = {}

    def pump():
        for line in proc.stdout:
            line = line.rstrip()
            if "trycloudflare.com" in line and "https://" in line:
                import re

                m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
                if m and "url" not in url_box:
                    url_box["url"] = m.group(0)
                    print("=" * 74, flush=True)
                    print(f"  PUBLIC URL →  {m.group(0)}", flush=True)
                    print("  paste that into the web app: Settings → My GPU server", flush=True)
                    print("=" * 74, flush=True)
            elif line:
                print(f"   [cloudflared] {line}", flush=True)

    threading.Thread(target=pump, daemon=True).start()
    for _ in range(60):
        if "url" in url_box:
            return url_box["url"]
        time.sleep(0.5)
    return url_box.get("url")


def _download(url, target):
    import urllib.request
    import tarfile

    tmp = target + ".download"
    urllib.request.urlretrieve(url, tmp)
    if url.endswith(".tgz"):
        with tarfile.open(tmp) as tf:
            tf.extractall(os.path.dirname(os.path.abspath(target)) or ".")
        os.remove(tmp)
    else:
        os.replace(tmp, target)


# --------------------------------------------------------------------------- #
def download_only(engine, ids):
    """Fetch model weights and exit — the offline way to prepare a machine.

    Uses the same queue as a generation, so the progress messages are identical
    and an interrupted run resumes where it stopped.
    """
    wanted = [i.strip() for i in str(ids).split(",") if i.strip()]
    if wanted == ["all"]:
        wanted = [m["id"] for m in MODELS]
    unknown = [i for i in wanted if i not in MODEL_BY_ID]
    if unknown:
        print(f"  unknown model id(s): {', '.join(unknown)}")
        print(f"  known ids: {', '.join(m['id'] for m in MODELS)}")
        return 2
    total = 0.0
    failed = []
    for mid in wanted:
        spec = MODEL_BY_ID[mid]
        size = f"~{spec['sizeGb']:g} GB" if spec.get("sizeGb") else "size unknown"
        print(f"\n== {spec['label']} ({mid}) — {size}", flush=True)
        job = engine.start_download(mid)
        last = ""
        while job.state not in ("done", "error", "cancelled"):
            if job.message and job.message != last:
                last = job.message
                print(f"   {job.progress * 100:5.1f}%  {last}", flush=True)
            time.sleep(1.0)
        if job.state == "done":
            entry = engine.weights.peek(spec["repo"]) or {}
            gb = entry.get("gb") or 0
            total += gb
            print(f"   done — {gb:g} GB on disk ({job.elapsed:.0f}s)", flush=True)
        else:
            failed.append(mid)
            print(f"   FAILED — {job.error or job.message}", flush=True)
    ok = len(wanted) - len(failed)
    print(f"\n  {ok}/{len(wanted)} ready, {total:g} GB total in {engine.weights.root}", flush=True)
    if failed:
        print(f"  failed: {', '.join(failed)}", flush=True)
        return 1
    return 0

def main(argv=None):
    p = argparse.ArgumentParser(description="AIVideoGen self-hosted video server")
    p.add_argument("--host", default="127.0.0.1", help="bind address (0.0.0.0 to expose on your LAN)")
    p.add_argument("--port", type=int, default=7860)
    p.add_argument("--model", default="wan5b", help="default model id")
    p.add_argument("--dtype", default=None, help="force the weight precision (float16 / bfloat16 / float32 / float8_e4m3fn)")
    p.add_argument(
        "--precision",
        choices=["auto", "fp32", "fp16", "bf16", "fp8"],
        default=None,
        help="weight precision, by the name everyone uses: auto (default), fp32 for exactness, fp16/bf16 to halve VRAM, fp8 on Ada/Hopper",
    )
    p.add_argument("--offload", dest="offload", action="store_true", default=None, help="always use CPU offload")
    p.add_argument("--no-offload", dest="offload", action="store_false", help="never use CPU offload")
    p.add_argument("--preload", action="store_true", help="load the default model at start-up")
    p.add_argument("--preload-models", default="", help="comma-separated model ids to warm up")
    p.add_argument("--out", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs"))
    p.add_argument("--width", type=int, default=832)
    p.add_argument("--height", type=int, default=480)
    p.add_argument("--tunnel", choices=["none", "cloudflare"], default="none")
    p.add_argument("--key", default="", help="require this shared key on every /api/ call (recommended with --tunnel)")
    p.add_argument(
        "--source",
        choices=["auto", "ms", "hf"],
        default=os.environ.get("AIVIDEOGEN_SOURCE", "auto"),
        help="where model weights come from: auto = ModelScope, then Hugging Face (default)",
    )
    p.add_argument(
        "--hf-endpoint",
        default=os.environ.get("HF_ENDPOINT", ""),
        help="Hugging Face endpoint, e.g. https://hf-mirror.com for regions where huggingface.co is slow or blocked",
    )
    p.add_argument(
        "--cache",
        default=os.environ.get("AIVIDEOGEN_CACHE", os.path.join("~", ".cache", "aivideogen")),
        help="cache root (default ~/.cache/aivideogen)",
    )
    p.add_argument(
        "--models-dir",
        default=os.environ.get("AIVIDEOGEN_MODELS", ""),
        help="where the weights live (default <cache>/models)",
    )
    p.add_argument("--revision", default=None, help="model repo revision to use (branch, tag or commit)")
    p.add_argument("--offline", action="store_true", help="never download: fail if the weights are not already cached")
    p.add_argument(
        "--lora",
        default="",
        help="attach these adapters to every job (comma-separated ids from the LoRA catalogue: "
        "distill, nsfw, nsfw_anatomy, motion — or <repo>[:<filename>] / a local folder)",
    )
    p.add_argument("--no-lora", dest="no_lora", action="store_true", help="do not attach the preset distillation LoRA")
    p.add_argument("--download", default="", help="fetch these model ids (comma-separated) and exit")
    p.add_argument("--weights", action="store_true", help="print the weights cache and exit")
    p.add_argument("--list", action="store_true", help="print the model catalogue and exit")
    args = p.parse_args(argv)

    # `--precision fp16` and `--dtype float16` mean the same thing; the former is
    # the name the rest of the world uses, so it wins when both are given.
    if args.precision:
        args.dtype = args.precision

    if args.list:
        for m in MODELS:
            size = f"~{m['sizeGb']:g}GB" if m.get("sizeGb") else "  ?  "
            ms = m.get("ms") or "—"
            print(
                f"{m['id']:12} {m['label']:30} {m['maxSec']:>4}g  {size:>8} on disk  "
                f"~{m['vramGb']:>2}GB vram  {m['repo']}"
            )
            print(f"{'':12} modelscope: {ms}")
        return 0

    engine = Engine(args)
    engine.detect()

    if args.weights:
        print(f"  weights root  {engine.weights.root}")
        print(f"  source        {engine.args.source}   modelscope: {'yes' if engine.modelscope else 'no'}")
        if engine.args.hf_endpoint:
            print(f"  hf endpoint   {engine.args.hf_endpoint}")
        if not engine.weights.index:
            print("  (nothing cached yet — the first generation fetches what it needs)")
        for key, e in sorted(engine.weights.index.items()):
            print(f"  {key:56} {e.get('gb', 0):>7.2f} GB  {e.get('source') or '?':3}  {e.get('path')}")
        print("  --- LoRA adapters ---")
        for l in engine.lora_public():
            size = f"{l['sizeGb']:g} GB" if l["sizeGb"] else "?"
            print(
                f"  lora:{l['id']:16} {size:>7}  {'cached' if l['cached'] else '      '}  {l['repo']}"
            )
        return 0

    if args.download:
        return download_only(engine, args.download)

    os.makedirs(args.out, exist_ok=True)

    print("=" * 74)
    print("  AIVideoGen Server")
    print(f"  device: {engine.device}   gpu: {engine.gpu_name or '—'}   vram: {engine.vram or '—'} GB")
    print(f"  precision: {args.dtype or 'auto'}   adapters: {', '.join(args.lora.split(',')) if args.lora else ('preset only' if not args.no_lora else 'none')}")
    print(f"  models: {', '.join(m['id'] for m in MODELS)}")
    print("=" * 74)

    to_warm = [m.strip() for m in args.preload_models.split(",") if m.strip()]
    if args.preload:
        to_warm.insert(0, args.model)

    app = build_app(engine)

    if to_warm:
        def warm():
            for mid in to_warm:
                try:
                    engine.load(mid)
                except Exception as e:
                    engine.say(f"preload of {mid} failed: {e}", "warn")

        threading.Thread(target=warm, daemon=True).start()

    import uvicorn

    # Start serving first, then open the tunnel — so the public URL is never handed out
    # before the local port answers.
    server_thread = threading.Thread(
        target=lambda: uvicorn.run(app, host=args.host, port=args.port, log_level="warning"),
        daemon=True,
    )
    server_thread.start()
    time.sleep(1.2)

    if args.tunnel == "cloudflare":
        start_tunnel(args.port)

    print(f"\n  Local address →  http://{args.host}:{args.port}", flush=True)
    print("  (leave this running; press Ctrl+C to stop)\n", flush=True)

    try:
        while server_thread.is_alive():
            server_thread.join(1)
    except KeyboardInterrupt:
        print("\n  stopped")
    return 0


if __name__ == "__main__":
    sys.exit(main())
