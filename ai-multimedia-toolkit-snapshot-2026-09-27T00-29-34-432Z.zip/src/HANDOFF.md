# HANDOFF — read this first, every session

This file is the cross-chat memory. The chat has a length limit and the user
presses "new chat" when it gets long. When the user says **"resume from last
work" / "keep working" / "next"**: read this file, then immediately continue
from **Now / Next** below — do not ask what to do, do not re-plan from zero.

## Rule (standing)

Before starting any task: append the plan under `Log`. After finishing:
update `Last done`, move items between `Now` and `Next`, keep this file
under ~100 lines. The in-app side of this system is `src/v4-resume.js`
(auto-saves storyboard + tab on every keystroke, auto-restores silently on
boot, shows a "Resume last work" banner). The two systems mirror each other:
this file = agent memory, `v4-resume` = user memory.

## Who

- User name: krumppy. Call them that when they ask for a status update.

## Private builds (krumppy's request, agent-side, NOT in-app)

- Build: image-to-video model (SFW + NSFW) + LoRA + image-to-image (SFW + NSFW), on agent side.
- Status: not complete. When krumppy asks, give a short status update from here.
- Log:
  - 2026-09-26 — request saved. App-side i2v/LoRA/img2img integration done; private training pack not started.
  - 2026-09-26 — krumppy said start training agent-side. No training launched: this workspace has no GPU training compute, so weights cannot be trained here.

## Where things live

- `main.pjs` — config, `$meta` title = AI Multimedia Toolkit **V4**
- `index.html` — shell + `#pageStoryboard` (tab sits before Voiceover)
- `src/storyboard-studio.js` — Storyboard Studio (unlimited gen, board, compile)
- `src/storyboard.css` — board/viewer styles
- `src/v4-resume.js` — autosave + silent restore + resume banner
- `src/README.md` — architecture map (update it when adding files)

## Last done (2026-09-27)

S1 story built LIVE for krumppy: project "Maya & Rio — Lisbon Crane", 16:9, 10/10 frames on board with character-lock prompts, cast renamed (Maya — courier girl, Rio — fox companion), scene (Old Lisbon Alley Dusk), wardrobe (Teal Courier Jacket), viewer preview verified by screenshot, autosaved (project persist + Resume banner).

Storyboard Import-into-story shipped and verified live: renamable
Cast/Scenes/Wardrobe slots (computer or Library import, add/remove, Frame
button, outfit Use-to-prompt) + Character designer prompt builder with
Generate-into-slot; refs persist per project, no phone-width overflow,
Tutorial roadmap entry added.

Per-scene duration + transition picker shipped: each board card has its own
seconds input (sec/img is the default for new scenes), Compile offers
Cut / Dissolve 0.3s / 0.6s, timings + choice persist per project. Tutorial
roadmap entry added.
Feedback wall timeout fix shipped and verified live: Send is gated on
wall load (early Send keeps text with a wait note, no orphaned submit),
telemetry submits held until wall-up; ready wall posts normally.
Tutorial roadmap entry added.

Image models categorized like Video and verified live: grouped picker
(◆ Perchance built-in · ● Free · ○ Puter · ✦ Uncensored · ■ This device),
Perchance Best SFW + Best NSFW entries leading Auto, NSFW-gated uncensored
group, edit mode shows only edit-capable routes, honest no-native-
image-to-video note; live 512px generation delivered via Perchance route.
Tutorial roadmap entry added.

Storyboard voiceover export shipped and verified in live preview:
🎙 Voiceover sends one narration line per scene to the Voice tab
(Generate voice there, export WAV/MP3); ✨ Narrate AI-rewrites scenes
into spoken narration first. Tutorial roadmap entry added.

V4 storyboard project switcher shipped and verified in live preview:
Project dropdown + New/Delete above the story name, per-story auto-save
(localStorage + kv `sb_projects`), Library-grouped fallback for older
stories, switch restores frames with blobs, Tutorial roadmap entry added.
Storyboard UI audit shipped: themed ratio chips, accent badges, text-only
card tools, hidden empty player box; zero phone-width overflows on all tabs;
Library cards show no clipped text (dark modal + engine error badge are
pre-existing global behaviors, left untouched).

V4 storyboard update shipped and verified in live preview:
rename V3→V4, Storyboard tab, Perchance-model-first unlimited generation,
AI story builder / AI prompt / prompt enhancer, mic dictation, 10 ratios
with hover format hints + social-ready, 6 thumbnail views, numbered +
drag-reorder board, 2x/½ upscale, send-to-Video/Image/Editor/Voice/download,
story speech, ratio-live viewer, compile to WEBM/MP4/MOV/MKV auto-saved to
Library per story name + category, auto-ratio video player, nav self-heal
shim (live page was serving cached `app.js`, so the module repairs tab
switching itself — `src/app.js:2425` one-line list change is the permanent
fix once the user saves).

## Now (unfinished → do first on "resume/next")

1. Board thumbnail lazy-loading for 50+ frame stories.
2. Character wardrobe training loop (krumppy's task, 2026-09-27): S1 DONE + verified (Maya & Rio, 10 frames, 16:9, renamed slots, autosaved); next = S2 seed-lock per character + reference-image anchoring, internet consistency research, external help only via public docs.

## Next (queued, not started)

- Board thumbnail lazy-loading for 50+ frame stories.

## Log

- 2026-09-26 — V4 storyboard + resume system built, verified (board,
  numbering, 9:16 viewer ratio, compile→player ratio, all-tab switching).
- 2026-09-26 — NEXT: handoff file + silent auto-restore (this task).
- 2026-09-26 — DONE: `src/HANDOFF.md` created + linked from README standing
  rules; `v4-resume.js` boot now silently restores the storyboard (verified:
  fresh reload rebuilt 2-card "Test Story" with zero clicks).
- 2026-09-27 — wardrobe/10-frame story shipped + verified live (★ 10-frame button, 16:9 default, renamable cast/scene/wardrobe, character-lock clause, 3x fail-retry, autosave+resume, in-app roadmap entry).
